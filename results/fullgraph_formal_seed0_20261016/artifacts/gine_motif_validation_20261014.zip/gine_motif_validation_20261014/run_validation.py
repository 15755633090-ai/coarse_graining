"""Extend fixed readout protocol; reuse old runs and retrain new-split encoders."""
import argparse
import json
from pathlib import Path
from types import SimpleNamespace
import sys
import torch

HERE=Path(__file__).resolve().parent
BASE=HERE.parent/'gine_motif_readout_20261014'
sys.path.insert(0,str(BASE))
from run import sha,save_json,data_inputs,fit_encoder,cache_atoms,pack,fit_readout,ARMS,Baseline


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--device',default='cuda')
    p.add_argument('--resume',action='store_true')
    args=p.parse_args()
    args.dataset=HERE.parent/'datasets/lipo';args.epochs=200;args.patience=30
    out=HERE/'results';out.mkdir(exist_ok=True)
    original=BASE/'results'
    original_manifest=json.loads((original/'manifest.json').read_text(encoding='utf-8'))
    assert sha(BASE/'run.py')==original_manifest['script_sha256']
    assert sha(BASE/'PROTOCOL.md')==original_manifest['protocol_sha256']
    assert json.loads((original/'verification.json').read_text())['readout_runs']==27
    split_path=HERE/'split_manifest.json'
    new_ids=json.loads(split_path.read_text())['splits']
    splits,groups,identity=data_inputs(args)
    assert identity==original_manifest['identity']
    byid={int(g.row_id):g for values in splits.values() for g in values}
    new_split={key:[byid[i] for i in ids] for key,ids in new_ids.items()}
    manifest=dict(identity=identity,core_script_sha256=sha(BASE/'run.py'),
                  extension_script_sha256=sha(Path(__file__)),protocol_sha256=sha(HERE/'PROTOCOL.md'),
                  new_split_sha256=sha(split_path),
                  original_results_sha256=sha(original/'complete.json'),
                  original_manifest_sha256=sha(original/'manifest.json'),
                  encoder_seeds=[0,1,2,3,4],head_seeds=[0,1,2],epochs=200,patience=30,
                  device=args.device,torch=torch.__version__,minimum_effect_threshold=None,
                  confidence_interval='pointwise_two_sided_Student_t_95_percent_over_5_encoder_means')
    dest=out/'manifest.json'
    if dest.exists():
        if not args.resume:raise FileExistsError('Use --resume to continue exactly the saved protocol')
        assert json.loads(dest.read_text())==manifest
    else:save_json(dest,manifest)
    torch.set_num_threads(4)
    torch.backends.cuda.matmul.allow_tf32=False
    results=[dict(r,split_name='original',artifact_dir=str(original/f"encoder{r['encoder_seed']}"),reused=True)
             for r in json.loads((original/'complete.json').read_text())]
    progress=out/'progress.json'
    if args.resume and progress.exists():
        results=json.loads(progress.read_text())
    encoders=[]
    old_encoders=json.loads((original/'encoders.json').read_text())
    for enc in old_encoders:
        encoders.append(dict(enc,split_name='original',artifact_dir=str(original/f"encoder{enc['seed']}"),reused=True))
    save_json(progress,results)
    for split_name,split_data,seeds in [('original',splits,[3,4]),('new_scaffold',new_split,[0,1,2,3,4])]:
        for seed in seeds:
            folder=out/split_name/f'encoder{seed}'
            checkpoint=folder/'encoder_best.pt';cache_path=folder/'atom_cache.pt'
            if args.resume and checkpoint.exists():
                ck=torch.load(checkpoint,map_location='cpu',weights_only=True)
                model=Baseline().to(args.device);model.load_state_dict(ck['state_dict'])
                encoder=model.encoder.eval().requires_grad_(False);meta=ck['metadata']
            else:
                print(f'START {split_name} encoder {seed}',flush=True)
                encoder,checkpoint,meta=fit_encoder(split_data,seed,args,folder)
            if args.resume and cache_path.exists():
                cache=torch.load(cache_path,map_location='cpu',weights_only=True)
                assert cache['checkpoint_sha256']==sha(checkpoint)
                caches=cache['splits']
            else:caches,cache_path=cache_atoms(encoder,split_data,checkpoint,args,folder)
            del encoder
            for key in split_data:
                assert caches[key]['ids']==[int(g.row_id) for g in split_data[key]]
            encoders.append(dict(meta,checkpoint_sha256=sha(checkpoint),atom_cache_sha256=sha(cache_path),
                                 split_name=split_name,artifact_dir=str(folder),reused=False))
            save_json(out/'encoders.json',encoders)
            packed=pack(caches,groups,args.device)
            for head_seed in (0,1,2):
                for arm in ARMS:
                    found=[r for r in results if r['split_name']==split_name and r['encoder_seed']==seed
                           and r['head_seed']==head_seed and r['arm']==arm]
                    if found:continue
                    row=fit_readout(packed,arm,seed,head_seed,args,folder,cache_path)
                    results.append(dict(row,split_name=split_name,artifact_dir=str(folder),reused=False))
                    save_json(progress,results)
            del caches,packed
            if args.device.startswith('cuda'):torch.cuda.empty_cache()
    assert len(results)==90 and len(encoders)==10
    save_json(out/'complete.json',results)
    print('COMPLETE: original split 5 encoders + new scaffold split 5 encoders; 90 readouts total',flush=True)


if __name__=='__main__':main()
