# GINE Motif 分组读出：固定方案的最后一轮扩展验证

仅增加独立Encoder种子和独立Lipo数据划分，不修改模型或训练协议，不添加A0、随机区域、其他网络模块。

原划分：复用 `gine_motif_readout_20261014/results` 的3个Encoder和27个读出结果，新增Encoder seeds 3、4；每个仍为head seeds 0、1、2，A2/A1-HimNet/A1-HMG-MRL。

新划分：在同一4200个Lipo分子上，用RDKit非手性Bemis-Murcko scaffold将分子分组，按split seed=20261014打乱完整scaffold组，依次在80% train、10% valid预算内整组放入，否则放入test。同一scaffold不能跨集合，空骨架统一成同一个组。只依据SMILES，不能参考性质标签或实验分数。生成一次即固定，不搜索更有利的split。新划分运行Encoder seeds 0、1、2、3、4，各3个head seeds、3种读出。

直接调用上一轮run.py的模型、特征、训练、缓存、读出函数，原文件SHA256必须与已完成实验一致。仍为4层128维GINE，随机初始化无预训练，Encoder原子Sum预测头监督；validation-best后冻结。A1/A2的phi、预测头、初始化、训练顺序、目标缩放、batch、lr、weight decay、200epoch上限、patience=30均不改。

原始Motif复用核验文件，不重提取或改规则。未覆盖原子仅在读出适配时补singleton，按成员覆盖次数归一化。每个新划分的Encoder必须重新从随机初始化训练，不能复用旧划分训练过的Encoder，以避免旧训练集泄漏到新测试集。

新增7个Encoder、63次读出；连同旧结果总共10个(split,Encoder)组合、90次读出。两个split共用同一分子集且训练/测试可能交叉，不把它们视作10个完全独立的数据划分实验。

用户选择：**只报告区间，暂不设最小有意义改善阈值**。统计单位为每个split中的独立Encoder：先对该Encoder的3个配对head差值求均值，再对5个Encoder的均值计算平均差值、样本标准差及双侧Student-t 95%置信区间（df=4）。主指标为测试RMSE差值A1−A2，负值表示分组更好；验证差值同时报告。区间为每个比较单独的点态区间，不作多重比较校正或显著性宣称。n=5下t区间依赖近似正态假设，且仅反映当前split下初始化/训练随机性的波动，不是总体分子采样或所有split的置信区间。

不根据新增结果调参、换split、选分组、增加种子或延长训练。最终逐split报告是否方向一致以及区间的不确定性，不以“没有显著改善”证明无效，也不声称排除了任何特定改善幅度。本轮完成后停止自动追加实验。

保存：原实验引用及哈希、scaffold分组和新split行ID及完整性检查、各Encoder检查点/缓存哈希、逐运行预测和选模历史、按Encoder配对差值与区间、源数据/代码哈希、结果验证。
