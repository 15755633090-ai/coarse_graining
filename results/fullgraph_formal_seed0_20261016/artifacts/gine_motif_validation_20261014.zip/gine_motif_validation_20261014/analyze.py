"""Per-split encoder-level paired intervals; no minimum-effect threshold."""
import csv
import json
from pathlib import Path
import numpy as np
from scipy.stats import t
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

HERE=Path(__file__).resolve().parent
OUT=HERE/'results'


def interval(values):
    a=np.asarray(values,dtype=float);assert len(a)==5
    mean=float(a.mean());sd=float(a.std(ddof=1));half=float(t.ppf(.975,df=4)*sd/np.sqrt(5))
    return dict(mean=mean,sample_std=sd,lower=mean-half,upper=mean+half,n_encoders=5)


def main():
    rows=json.loads((OUT/'complete.json').read_text(encoding='utf-8'))
    assert len(rows)==90
    assert len({(r['split_name'],r['encoder_seed'],r['head_seed'],r['arm']) for r in rows})==90
    means=[];paired=[];summaries=[]
    for split in ('original','new_scaffold'):
        for seed in range(5):
            for arm in ('A2','A1-HimNet','A1-HMG-MRL'):
                block=[r for r in rows if r['split_name']==split and r['encoder_seed']==seed and r['arm']==arm]
                assert {r['head_seed'] for r in block}=={0,1,2}
                means.append(dict(split_name=split,encoder_seed=seed,arm=arm,
                                  valid_rmse=float(np.mean([r['valid_rmse'] for r in block])),
                                  test_rmse=float(np.mean([r['test_rmse'] for r in block]))))
            for method in ('A1-HimNet','A1-HMG-MRL'):
                head_deltas=[]
                for head in range(3):
                    a=next(r for r in rows if r['split_name']==split and r['encoder_seed']==seed and r['head_seed']==head and r['arm']==method)
                    b=next(r for r in rows if r['split_name']==split and r['encoder_seed']==seed and r['head_seed']==head and r['arm']=='A2')
                    head_deltas.append(dict(head_seed=head,valid_delta=a['valid_rmse']-b['valid_rmse'],test_delta=a['test_rmse']-b['test_rmse']))
                paired.append(dict(split_name=split,encoder_seed=seed,method=method,heads=head_deltas,
                                   valid_delta=float(np.mean([r['valid_delta'] for r in head_deltas])),
                                   test_delta=float(np.mean([r['test_delta'] for r in head_deltas]))))
        for method in ('A1-HimNet','A1-HMG-MRL'):
            block=[r for r in paired if r['split_name']==split and r['method']==method]
            summaries.append(dict(split_name=split,method=method,
                                  validation=interval([r['valid_delta'] for r in block]),
                                  test=interval([r['test_delta'] for r in block]),
                                  encoders_with_test_improvement=sum(r['test_delta']<0 for r in block)))
    for name,obj in [('per_encoder_means.json',means),('paired_differences.json',paired),('confidence_intervals.json',summaries)]:
        (OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
    with (OUT/'per_run.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    lines=['# Lipo GINE Motif 分组读出：扩展验证','',
           '模型和训练协议保持原样；原划分补足5个Encoder，新scaffold划分5个Encoder，每个3个配对head种子。共90次读出，其中27次引用上一轮完成结果，63次新增。无A0、随机区域或新网络模块。',
           '按用户选择，仅报告区间，不设最小有意义改善阈值，也不作“证明无效”或等效性判断。','',
           '## 各划分的预测分数','',
           '|划分|读出|验证RMSE均值±Encoder间标准差|测试RMSE均值±Encoder间标准差|','|---|---|---:|---:|']
    for split in ('original','new_scaffold'):
        for arm in ('A2','A1-HimNet','A1-HMG-MRL'):
            block=[r for r in means if r['split_name']==split and r['arm']==arm]
            vals=[f"{np.mean([r[k] for r in block]):.5f} ± {np.std([r[k] for r in block],ddof=1):.5f}" for k in ('valid_rmse','test_rmse')]
            lines.append(f'|{split}|{arm}|{vals[0]}|{vals[1]}|')
    lines+=['','## 主比较：测试RMSE差值（分组 − A2）','',
            '|划分|分组|配对差值均值|95%置信区间|测试改善的Encoder数|','|---|---|---:|---|---:|']
    for row in summaries:
        s=row['test']
        lines.append(f"|{row['split_name']}|{row['method']}|{s['mean']:+.5f}|[{s['lower']:+.5f}, {s['upper']:+.5f}]|{row['encoders_with_test_improvement']}/5|")
    lines+=['','负值表示分组更好。统计单位是独立Encoder：每个Encoder先平均3个配对head差值，再对5个Encoder求Student-t区间（df=4）。多个head不是独立Encoder。',
            '这是逐比较点态95%区间，不做多重比较校正；n=5依赖近似正态假设，区间仅反映固定split下初始化/训练随机性，并不涵盖总体分子采样或所有可能数据划分。','',
            '## 收束边界','',
            '两个split使用同一分子集，训练/测试集合存在交叉，不能合并成10个独立数据划分样本。原split前3个Encoder结果此前已看过，扩展不是完全全新的盲验证；新split一次生成后固定，没有按结果搜索。',
            '若区间跨0，方向仍有不确定性；即便区间不跨0，也不推广为所有Motif建模有效或无效。不设效应阈值意味着本轮不能宣称排除了某个最小有意义改善。',
            '本轮完成后不自动增加实验，不依据测试结果修改phi、分组或训练预算。论文提取规则复用，论文完整网络未复现。','',
            '新split的行ID、scaffold隔离及新旧重合见上级split_manifest.json。逐Encoder差值和各head分数均保存；结果核验见verification.json。']
    (OUT/'RESULTS.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    plot(summaries)
    print(json.dumps(summaries,ensure_ascii=False,indent=2))


def plot(rows):
    fig,axis=plt.subplots(figsize=(9,4))
    axis.axvline(0,color='#333',lw=1)
    colors={'A1-HimNet':'#2563eb','A1-HMG-MRL':'#d97706'}
    names=[]
    for i,row in enumerate(rows):
        s=row['test'];axis.errorbar(s['mean'],i,xerr=[[s['mean']-s['lower']],[s['upper']-s['mean']]],
                                    fmt='o',capsize=5,color=colors[row['method']])
        names.append(row['split_name']+' / '+row['method'])
    axis.set_yticks(range(len(rows)),names);axis.invert_yaxis()
    axis.set_xlabel('Test RMSE difference: grouped readout - A2 (negative = better)')
    axis.set_title('5 encoders per split; pointwise 95% t intervals; no minimum-effect threshold')
    axis.grid(axis='x',alpha=.2);fig.tight_layout()
    fig.savefig(OUT/'confidence_intervals.png',dpi=180);plt.close(fig)


if __name__=='__main__':main()
