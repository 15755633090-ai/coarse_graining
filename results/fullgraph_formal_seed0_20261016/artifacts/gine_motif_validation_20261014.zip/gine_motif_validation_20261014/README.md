# 固定方案的扩展验证

在工作区根目录使用 `C:/Users/12775/miniconda3/envs/polyolefin_ml/python.exe`。

```powershell
& C:/Users/12775/miniconda3/envs/polyolefin_ml/python.exe coarse_graining1/gine_motif_validation_20261014/prepare_split.py
& C:/Users/12775/miniconda3/envs/polyolefin_ml/python.exe coarse_graining1/gine_motif_validation_20261014/run_validation.py
& C:/Users/12775/miniconda3/envs/polyolefin_ml/python.exe coarse_graining1/gine_motif_validation_20261014/analyze.py
& C:/Users/12775/miniconda3/envs/polyolefin_ml/python.exe coarse_graining1/gine_motif_validation_20261014/verify_results.py
```

split生成过后不重生成。若中断，使用 `python.exe -X utf8 run_validation.py --resume` 继续（Windows中文路径需要UTF-8模式）；它检查协议与源码哈希，复用已完成检查点、缓存和结果，不重复评价已有测试预测。原3个Encoder和27次读出只引用，原文件不修改。

完整协议见 `PROTOCOL.md`。本轮只增加Encoder种子3、4及一个固定随机化scaffold划分。新增7个Encoder和63次读出，总计两个split各5个Encoder、90次读出。两个split分别计算配对区间，不合并为10个独立数据划分。

用户选择只报告区间，不设最小有意义改善阈值。完成本轮后不自动增加种子、搜索split或改变模型。核心模型/训练代码直接复用已完成实验的 `gine_motif_readout_20261014/run.py`。
