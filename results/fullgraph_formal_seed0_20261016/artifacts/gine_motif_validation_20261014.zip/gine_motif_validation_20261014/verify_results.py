"""Validate both partitions and every reused/new prediction record."""
import json
from pathlib import Path
import sys
import numpy as np
import torch
from torch_geometric.data import Batch
from types import SimpleNamespace

HERE=Path(__file__).resolve().parent
BASE=HERE.parent/'gine_motif_readout_20261014'
sys.path.insert(0,str(BASE))
from run import sha,data_inputs,Baseline


def main():
    out=HERE/'results'
    manifest=json.loads((out/'manifest.json').read_text(encoding='utf-8'))
    assert sha(BASE/'run.py')==manifest['core_script_sha256']
    assert sha(HERE/'run_validation.py')==manifest['extension_script_sha256']
    assert sha(HERE/'PROTOCOL.md')==manifest['protocol_sha256']
    assert sha(HERE/'split_manifest.json')==manifest['new_split_sha256']
    assert sha(BASE/'results/complete.json')==manifest['original_results_sha256']
    assert sha(BASE/'results/manifest.json')==manifest['original_manifest_sha256']
    splits,groups,identity=data_inputs(SimpleNamespace(dataset=HERE.parent/'datasets/lipo'))
    assert identity==manifest['identity']
    byid={int(g.row_id):g for values in splits.values() for g in values}
    split_meta=json.loads((HERE/'split_manifest.json').read_text(encoding='utf-8'))
    new={key:[byid[i] for i in ids] for key,ids in split_meta['splits'].items()}
    for a,b in [('train','valid'),('train','test'),('valid','test')]:
        assert not {split_meta['scaffolds'][int(g.row_id)] for g in new[a]} & {split_meta['scaffolds'][int(g.row_id)] for g in new[b]}
    results=json.loads((out/'complete.json').read_text(encoding='utf-8'))
    encoders=json.loads((out/'encoders.json').read_text(encoding='utf-8'))
    assert len(results)==90 and len(encoders)==10
    assert len({(r['split_name'],r['encoder_seed'],r['head_seed'],r['arm']) for r in results})==90
    torch.set_num_threads(4);torch.backends.cuda.matmul.allow_tf32=False
    device=manifest['device']
    for enc in encoders:
        folder=Path(enc['artifact_dir']);cp=folder/'encoder_best.pt';cf=folder/'atom_cache.pt'
        assert sha(cp)==enc['checkpoint_sha256'] and sha(cf)==enc['atom_cache_sha256']
        ck=torch.load(cp,map_location='cpu',weights_only=True)
        assert ck['metadata']['random_initialization'] and not ck['metadata']['test_evaluated']
        assert abs(min(h['valid_rmse'] for h in ck['history'])-enc['valid_rmse'])<1e-7
        cache=torch.load(cf,map_location='cpu',weights_only=True)
        assert cache['encoder_frozen'] and cache['checkpoint_sha256']==sha(cp)
        dataset=splits if enc['split_name']=='original' else new
        model=Baseline().to(device);model.load_state_dict(ck['state_dict']);model.eval().requires_grad_(False)
        with torch.no_grad():
            errors=[]
            for i in range(0,len(dataset['valid']),64):
                batch=Batch.from_data_list(dataset['valid'][i:i+64]).to(device)
                errors.append((model(batch)*ck['target_std']+ck['target_mean']-batch.y).square())
            assert abs(float(torch.cat(errors).mean().sqrt())-enc['valid_rmse'])<1e-6
            for split in dataset:
                assert cache['splits'][split]['ids']==[int(g.row_id) for g in dataset[split]]
                torch.testing.assert_close(cache['splits'][split]['y'],torch.cat([g.y for g in dataset[split]]),rtol=0,atol=0)
                atoms=model.encoder(Batch.from_data_list(dataset[split][:16]).to(device)).cpu()
                torch.testing.assert_close(atoms,torch.cat(cache['splits'][split]['atoms'][:16]),atol=2e-5,rtol=2e-5)
        for row in [r for r in results if r['split_name']==enc['split_name'] and r['encoder_seed']==enc['seed']]:
            name=f"{row['arm']}_head{row['head_seed']}"
            head=torch.load(folder/(name+'.pt'),map_location='cpu',weights_only=True)
            assert all(row[k]==v for k,v in head['metadata'].items())
            assert sum(v.numel() for v in head['state_dict'].values())==49665
            assert row['parameters']==49665 and row['atom_cache_sha256']==sha(cf)
            assert abs(min(h['valid_rmse'] for h in head['history'])-row['valid_rmse'])<1e-6
            with np.load(folder/(name+'_predictions.npz')) as p:
                for split in ('valid','test'):
                    assert np.array_equal(p[split+'_ids'],cache['splits'][split]['ids'])
                    score=float(np.mean((p[split]-cache['splits'][split]['y'].numpy())**2)**.5)
                    assert abs(score-row[split+'_rmse'])<1e-6
        print(f"Verified {enc['split_name']} encoder {enc['seed']}",flush=True)
    proof=dict(encoder_partition_combinations=10,readout_runs=90,original_runs_reused=27,
               newly_trained_encoders=7,new_readout_runs=63,scaffold_disjoint=True,
               new_split_encoders_random_initialization=True,source_and_cache_hashes_confirmed=True,
               validation_selection_and_scores_recomputed=True,atomic_cache_examples_recomputed=True,
               prediction_row_ids_and_RMSE_confirmed=True,minimum_effect_threshold=None)
    (out/'verification.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
