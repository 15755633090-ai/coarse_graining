"""A single label-blind randomized scaffold split; never modify source datasets."""
from collections import defaultdict
import csv
import gzip
import json
from pathlib import Path
import numpy as np
from rdkit import Chem,rdBase
from rdkit.Chem.Scaffolds import MurckoScaffold
import sys

HERE=Path(__file__).resolve().parent
BASE=HERE.parent/'gine_motif_readout_20261014'
sys.path.insert(0,str(BASE))
from run import sha,save_json


def main():
    mapping=HERE.parent/'datasets/lipo/mapping/mol.csv.gz'
    destination=HERE/'split_manifest.json'
    if destination.exists():raise FileExistsError('Preserve the first generated split')
    with gzip.open(mapping,'rt',encoding='utf-8-sig') as f:smiles=[r['smiles'] for r in csv.DictReader(f)]
    groups=defaultdict(list);scaffolds=[]
    for idx,s in enumerate(smiles):
        mol=Chem.MolFromSmiles(s);assert mol is not None
        scaffold=MurckoScaffold.MurckoScaffoldSmiles(mol=mol,includeChirality=False)
        groups[scaffold].append(idx);scaffolds.append(scaffold)
    keys=sorted(groups)
    np.random.RandomState(20261014).shuffle(keys)
    split={s:[] for s in ('train','valid','test')}
    limits={'train':int(.8*len(smiles)),'valid':int(.1*len(smiles))}
    for key in keys:
        rows=groups[key]
        target='train' if len(split['train'])+len(rows)<=limits['train'] else (
            'valid' if len(split['valid'])+len(rows)<=limits['valid'] else 'test')
        split[target].extend(rows)
    # Sort only rows inside each fixed split; shuffle training order during fitting.
    split={key:sorted(value) for key,value in split.items()}
    assert sum(len(v) for v in split.values())==len(smiles)==4200
    assert len(set(i for values in split.values() for i in values))==4200
    sets={key:{scaffolds[i] for i in ids} for key,ids in split.items()}
    for a,b in (('train','valid'),('train','test'),('valid','test')):assert not sets[a]&sets[b]
    old={}
    for key in split:
        with gzip.open(HERE.parent/f'datasets/lipo/split/scaffold/{key}.csv.gz','rt') as f:
            old[key]=[int(x) for x in f if x.strip()]
    assert any(set(split[k])!=set(old[k]) for k in split)
    counts={key:len(ids) for key,ids in split.items()}
    comparisons={key:len(set(ids)&set(old[key])) for key,ids in split.items()}
    manifest=dict(split_seed=20261014,method='label_blind_randomized_Murcko_scaffold_groups',
                  source_mapping_sha256=sha(mapping),script_sha256=sha(Path(__file__)),rdkit=rdBase.rdkitVersion,
                  splits=split,counts=counts,original_split_same_partition_overlap=comparisons,
                  scaffolds=scaffolds,scaffold_group_count=len(groups),scaffold_disjoint=True,
                  partition_complete=True,labels_accessed=False,split_search=False)
    save_json(destination,manifest)
    print(json.dumps({k:v for k,v in manifest.items() if k not in ('splits','scaffolds')},indent=2))


if __name__=='__main__':main()
