"""Verify checkpoints, cache provenance and paired saved prediction metrics."""
import json
from pathlib import Path
import numpy as np
import torch
from torch_geometric.data import Batch
from run import HERE,sha,data_inputs,Baseline,ARMS
from types import SimpleNamespace

out=HERE/'results'
manifest=json.loads((out/'manifest.json').read_text(encoding='utf-8'))
assert not manifest['smoke']
assert sha(HERE/'run.py')==manifest['script_sha256']
assert sha(HERE/'PROTOCOL.md')==manifest['protocol_sha256']
for path,expected in manifest['identity']['data_sha256'].items():assert sha(Path(path))==expected
args=SimpleNamespace(dataset=HERE.parent/'datasets/lipo')
splits,groups,identity=data_inputs(args)
assert identity==manifest['identity']
encoders=json.loads((out/'encoders.json').read_text(encoding='utf-8'))
results=json.loads((out/'complete.json').read_text(encoding='utf-8'))
assert len(results)==len(manifest['encoder_seeds'])*len(manifest['head_seeds'])*len(ARMS)
assert len({(r['encoder_seed'],r['head_seed'],r['arm']) for r in results})==len(results)
torch.set_num_threads(4)
torch.backends.cuda.matmul.allow_tf32=False
device='cuda' if torch.cuda.is_available() else 'cpu'
for enc in encoders:
    folder=out/f"encoder{enc['seed']}"
    cp=folder/'encoder_best.pt';cachefile=folder/'atom_cache.pt'
    assert sha(cp)==enc['checkpoint_sha256'] and sha(cachefile)==enc['atom_cache_sha256']
    ck=torch.load(cp,map_location='cpu',weights_only=True)
    assert ck['metadata']['random_initialization'] and not ck['metadata']['test_evaluated']
    assert abs(min(h['valid_rmse'] for h in ck['history'])-enc['valid_rmse'])<1e-7
    cache=torch.load(cachefile,map_location='cpu',weights_only=True)
    assert cache['checkpoint_sha256']==sha(cp) and cache['encoder_frozen']
    model=Baseline().to(device);model.load_state_dict(ck['state_dict']);model.eval().requires_grad_(False)
    errors=[]
    with torch.no_grad():
        for i in range(0,len(splits['valid']),64):
            b=Batch.from_data_list(splits['valid'][i:i+64]).to(device)
            errors.append((model(b)*ck['target_std']+ck['target_mean']-b.y).square())
        actual=float(torch.cat(errors).mean().sqrt())
        assert abs(actual-enc['valid_rmse'])<1e-6
        for split in splits:
            block=splits[split][:16]
            h=model.encoder(Batch.from_data_list(block).to(device)).cpu()
            expected=torch.cat(cache['splits'][split]['atoms'][:16])
            torch.testing.assert_close(h,expected,atol=2e-5,rtol=2e-5)
    for split in splits:
        assert cache['splits'][split]['ids']==[int(g.row_id) for g in splits[split]]
        torch.testing.assert_close(cache['splits'][split]['y'],torch.cat([g.y for g in splits[split]]),rtol=0,atol=0)
    for row in [r for r in results if r['encoder_seed']==enc['seed']]:
        name=f"{row['arm']}_head{row['head_seed']}"
        head=torch.load(folder/(name+'.pt'),map_location='cpu',weights_only=True)
        assert head['metadata']==row
        assert row['parameters']==49665 and row['atom_cache_sha256']==sha(cachefile)
        assert abs(min(h['valid_rmse'] for h in head['history'])-row['valid_rmse'])<1e-6
        with np.load(folder/(name+'_predictions.npz')) as preds:
            for split in ('valid','test'):
                assert np.array_equal(preds[split+'_ids'],cache['splits'][split]['ids'])
                score=float(np.mean((preds[split]-cache['splits'][split]['y'].numpy())**2)**.5)
                assert abs(score-row[split+'_rmse'])<1e-6
proof=dict(encoder_runs=len(encoders),readout_runs=len(results),data_hashes_confirmed=True,
           structure_hash_confirmed=True,random_encoder_initialization=True,
           encoder_validation_metric_recomputed=True,encoder_atomic_cache_recomputed_on_examples=True,
           same_cache_within_encoder=True,all_checkpoints_validation_best=True,
           saved_predictions_metrics_and_row_ids_confirmed=True)
(out/'verification.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(proof,ensure_ascii=False,indent=2))
