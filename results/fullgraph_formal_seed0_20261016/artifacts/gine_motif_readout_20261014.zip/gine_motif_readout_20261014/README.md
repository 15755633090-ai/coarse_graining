# GINE 第一批实验

运行环境：`C:/Users/12775/miniconda3/envs/polyolefin_ml/python.exe`。在工作区根目录执行：

```powershell
& C:/Users/12775/miniconda3/envs/polyolefin_ml/python.exe coarse_graining1/gine_motif_readout_20261014/check_model.py
& C:/Users/12775/miniconda3/envs/polyolefin_ml/python.exe coarse_graining1/gine_motif_readout_20261014/run.py
& C:/Users/12775/miniconda3/envs/polyolefin_ml/python.exe coarse_graining1/gine_motif_readout_20261014/verify_results.py
```

完整协议见 `PROTOCOL.md`。此实现只适用于当前已审计的Lipo单目标回归数据。`--smoke --output 新目录`运行小数据流程验证，结果不计入正式证据。脚本拒绝覆盖已经存在的manifest；新实验用`--output 新目录`。默认核验脚本针对默认 `results` 目录。

默认训练3个独立随机初始化GINE Encoder，分别冻结并缓存原子状态，各训练3个配对head种子、3种读出。数据不调用扩散代码、不加载扩散权重或缓存。原始Motif不更改，读出适配时才处理singleton与覆盖归一化。

输出包含每个Encoder的validation-best检查点、逐epoch历史、冻结原子缓存及哈希；每个读出检查点、历史、验证/测试预测和源行ID；逐运行结果、各Encoder内head均值、配对差值及核验记录。
