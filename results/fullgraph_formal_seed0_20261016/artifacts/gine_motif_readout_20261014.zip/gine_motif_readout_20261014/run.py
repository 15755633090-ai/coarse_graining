"""Ordinary GINE baseline, then matched frozen Motif readouts. Lipo only."""
from __future__ import annotations
import argparse
import copy
import csv
import gzip
import hashlib
import json
from pathlib import Path
import time

import numpy as np
import torch
from torch import nn
import torch.nn.functional as F
from rdkit import Chem
from torch_geometric.data import Data
from torch_geometric.loader import DataLoader
from torch_geometric.nn import GINEConv, global_add_pool

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
ATOM_DIMS=(119,12,17,16,16,10,2,2)
BOND_DIMS=(6,16,2,2)
ARMS=('A2','A1-HimNet','A1-HMG-MRL')


def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()


def save_json(path,value):
    tmp=path.with_suffix('.tmp')
    tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
    tmp.replace(path)


def seed_all(seed):
    torch.manual_seed(seed)
    np.random.seed(seed)
    torch.backends.cuda.matmul.allow_tf32=False
    torch.backends.cudnn.benchmark=False


def graph(smiles,idx,label):
    mol=Chem.MolFromSmiles(smiles)
    if mol is None:raise ValueError(f'Invalid molecule {idx}')
    atoms=[[a.GetAtomicNum(),a.GetDegree(),a.GetFormalCharge()+8,int(a.GetChiralTag()),
            int(a.GetHybridization()),a.GetTotalNumHs(),int(a.GetIsAromatic()),int(a.IsInRing())]
           for a in mol.GetAtoms()]
    types={Chem.BondType.SINGLE:1,Chem.BondType.DOUBLE:2,Chem.BondType.TRIPLE:3,Chem.BondType.AROMATIC:4}
    pairs=[];attrs=[]
    for b in mol.GetBonds():
        a,c=b.GetBeginAtomIdx(),b.GetEndAtomIdx()
        feat=[types.get(b.GetBondType(),5),int(b.GetStereo()),int(b.GetIsConjugated()),int(b.IsInRing())]
        pairs.extend([(a,c),(c,a)]);attrs.extend([feat,feat])
    x=torch.tensor(atoms,dtype=torch.long)
    ea=torch.tensor(attrs,dtype=torch.long).reshape(-1,4)
    ei=torch.tensor(pairs,dtype=torch.long).reshape(-1,2).T.contiguous()
    for array,dims in ((x,ATOM_DIMS),(ea,BOND_DIMS)):
        for col,bound in enumerate(dims):
            assert array.numel()==0 or bool(((array[:,col]>=0)&(array[:,col]<bound)).all()),(idx,col,bound)
    return Data(x=x,edge_index=ei,edge_attr=ea,y=torch.tensor([label],dtype=torch.float32),
                row_id=torch.tensor([idx]),num_nodes=len(atoms))


def data_inputs(args):
    structural=ROOT/'motif_structure_audit_20261014/outputs'
    source=structural/'verified_motifs.json'
    verification=json.loads((structural/'manifest.json').read_text(encoding='utf-8'))
    assert verification['unresolved_structural_errors']==0
    assert sha(source)==verification['verified_data_sha256']
    records=json.loads(source.read_text(encoding='utf-8'))
    groups={}
    for r in records:
        idx=r['source_row'];n=len(r['atoms'])
        raw=[m['atoms'] for m in r['motifs']]
        counts=np.zeros(n,dtype=np.int64)
        for g in raw:counts[g]+=1
        assert counts.tolist()==r['original_coverage_counts']
        missing=np.flatnonzero(counts==0).tolist()
        assert missing==r['uncovered_atoms']
        groups[(idx,r['method'])]=(raw+[[i] for i in missing],np.maximum(counts,1))
    mapping=args.dataset/'mapping/mol.csv.gz'
    labels_file=args.dataset/'raw/graph-label.csv.gz'
    with gzip.open(mapping,'rt',encoding='utf-8-sig') as f:smiles=[r['smiles'] for r in csv.DictReader(f)]
    with gzip.open(labels_file,'rt',encoding='utf-8') as f:labels=[float(r[0]) for r in csv.reader(f)]
    assert len(smiles)==len(labels)==4200
    byid={r['source_row']:r for r in records if r['method']=='HimNet'}
    for idx,s in enumerate(smiles):assert byid[idx]['smiles']==s
    allgraphs=[graph(s,i,y) for i,(s,y) in enumerate(zip(smiles,labels))]
    splits={};files=[mapping,labels_file]
    seen=set()
    for split in ('train','valid','test'):
        path=args.dataset/f'split/scaffold/{split}.csv.gz';files.append(path)
        with gzip.open(path,'rt') as f:ids=[int(x.strip()) for x in f if x.strip()]
        assert not seen.intersection(ids);seen.update(ids)
        assert all(byid[i]['split']==split for i in ids)
        splits[split]=[allgraphs[i] for i in ids]
    assert len(seen)==4200
    identity=dict(structural_data_sha256=sha(source),structure_audit_sha256=sha(structural/'manifest.json'),
                  data_sha256={str(p):sha(p) for p in files},molecules={k:len(v) for k,v in splits.items()},
                  atom_features=list(ATOM_DIMS),bond_features=list(BOND_DIMS),
                  encoder_family='GINE',pretraining=False)
    return splits,groups,identity


class Embed(nn.Module):
    def __init__(self,dims,d):
        super().__init__();self.embeddings=nn.ModuleList(nn.Embedding(n,d) for n in dims)
    def forward(self,x):
        return sum(e(x[:,i]) for i,e in enumerate(self.embeddings))


class Encoder(nn.Module):
    def __init__(self,d=128,layers=4):
        super().__init__()
        self.atom=Embed(ATOM_DIMS,d);self.bond=Embed(BOND_DIMS,d)
        self.convs=nn.ModuleList(GINEConv(nn.Sequential(nn.Linear(d,d),nn.SiLU(),nn.Linear(d,d)),train_eps=True)
                                 for _ in range(layers))
        self.norms=nn.ModuleList(nn.LayerNorm(d) for _ in range(layers))
    def forward(self,batch):
        h=self.atom(batch.x);e=self.bond(batch.edge_attr)
        for i,(conv,norm) in enumerate(zip(self.convs,self.norms)):
            h=F.silu(norm(conv(h,batch.edge_index,e)))
            if i+1<len(self.convs):h=F.dropout(h,p=.1,training=self.training)
        return h


def prediction_head(d=128):
    return nn.Sequential(nn.Linear(d,128),nn.SiLU(),nn.Dropout(.1),nn.Linear(128,1))


class Baseline(nn.Module):
    def __init__(self):
        super().__init__();self.encoder=Encoder();self.head=prediction_head()
    def forward(self,batch):
        return self.head(global_add_pool(self.encoder(batch),batch.batch)).squeeze(-1)


def fit_encoder(splits,seed,args,folder):
    folder.mkdir(parents=True,exist_ok=True)
    seed_all(seed)
    model=Baseline().to(args.device)
    before={k:v.detach().cpu().clone() for k,v in model.encoder.state_dict().items()}
    train_y=torch.tensor([float(g.y) for g in splits['train']])
    mean=float(train_y.mean());std=float(train_y.std(unbiased=False))
    optimizer=torch.optim.AdamW(model.parameters(),lr=.001,weight_decay=1e-5)
    train=DataLoader(splits['train'],batch_size=64,shuffle=True,num_workers=0,
                     generator=torch.Generator().manual_seed(seed+1000))
    valid=DataLoader(splits['valid'],batch_size=64,shuffle=False,num_workers=0)
    best=float('inf');best_epoch=-1;state=None;history=[];started=time.perf_counter()
    for epoch in range(args.epochs):
        model.train()
        for batch in train:
            batch=batch.to(args.device);optimizer.zero_grad(set_to_none=True)
            loss=(model(batch)-(batch.y-mean)/std).square().mean()
            assert torch.isfinite(loss)
            loss.backward();nn.utils.clip_grad_norm_(model.parameters(),5);optimizer.step()
        model.eval();errors=[]
        with torch.no_grad():
            for batch in valid:
                batch=batch.to(args.device);errors.append((model(batch)*std+mean-batch.y).square())
        score=float(torch.cat(errors).mean().sqrt())
        history.append(dict(epoch=epoch+1,valid_rmse=score))
        if score<best:best=score;best_epoch=epoch;state=copy.deepcopy(model.state_dict())
        if epoch==0 or (epoch+1)%10==0:
            print(f'GINE encoder {seed}: epoch {epoch+1}, best valid RMSE {best:.5f}',flush=True)
        if epoch-best_epoch>=args.patience:break
    model.load_state_dict(state)
    assert any(not torch.equal(before[k],v.cpu()) for k,v in model.encoder.state_dict().items())
    meta=dict(seed=seed,valid_rmse=best,best_epoch=best_epoch+1,epochs_ran=len(history),
              parameters=sum(p.numel() for p in model.parameters()),seconds=time.perf_counter()-started,
              random_initialization=True,test_evaluated=False)
    checkpoint=folder/'encoder_best.pt'
    torch.save(dict(state_dict={k:v.cpu() for k,v in state.items()},metadata=meta,history=history,
                    target_mean=mean,target_std=std),checkpoint)
    save_json(folder/'encoder_history.json',dict(metadata=meta,history=history))
    encoder=model.encoder.eval().requires_grad_(False)
    for p in encoder.parameters():p.grad=None
    return encoder,checkpoint,meta


def cache_atoms(encoder,splits,checkpoint,args,folder):
    initial={k:v.cpu().clone() for k,v in encoder.state_dict().items()}
    caches={}
    for split,graphs in splits.items():
        loader=DataLoader(graphs,batch_size=64,shuffle=False,num_workers=0)
        rows=[];labels=[];ids=[]
        with torch.no_grad():
            for batch in loader:
                batch=batch.to(args.device);h=encoder(batch)
                pooled=global_add_pool(h,batch.batch)
                for i in range(batch.num_graphs):
                    atoms=h[batch.ptr[i]:batch.ptr[i+1]]
                    torch.testing.assert_close(atoms.sum(0),pooled[i],rtol=1e-5,atol=1e-4)
                    rows.append(atoms.cpu())
                labels.extend(batch.y.cpu().tolist());ids.extend(batch.row_id.cpu().tolist())
        assert ids==[int(g.row_id) for g in graphs]
        assert all(len(h)==g.num_nodes for h,g in zip(rows,graphs))
        caches[split]=dict(atoms=rows,y=torch.tensor(labels),ids=ids)
    assert all(p.grad is None and not p.requires_grad for p in encoder.parameters())
    assert all(torch.equal(initial[k],v.cpu()) for k,v in encoder.state_dict().items())
    path=folder/'atom_cache.pt'
    torch.save(dict(checkpoint_sha256=sha(checkpoint),splits=caches,encoder_frozen=True),path)
    return caches,path


def pack(caches,groups,device):
    packed={}
    for split,cache in caches.items():
        packed[split]=dict(y=cache['y'].to(device),ids=cache['ids'])
        options={'A2':cache['atoms']}
        for method in ('HimNet','HMG-MRL'):
            items=[]
            for idx,h in zip(cache['ids'],cache['atoms']):
                gs,counts=groups[(idx,method)]
                vectors=torch.stack([(h[g]/torch.tensor(counts[g,None])).sum(0) for g in gs]).float()
                torch.testing.assert_close(vectors.sum(0),h.sum(0),rtol=1e-5,atol=1e-4)
                items.append(vectors)
            options['A1-'+method]=items
        for arm,items in options.items():
            x=torch.zeros(len(items),max(len(h) for h in items),128,device=device)
            mask=torch.zeros(x.shape[:2],dtype=torch.bool,device=device)
            for i,h in enumerate(items):x[i,:len(h)]=h.to(device);mask[i,:len(h)]=True
            packed[split][arm]=(x,mask)
    return packed


class Readout(nn.Module):
    def __init__(self,seed):
        super().__init__()
        torch.manual_seed(10000+seed);self.head=prediction_head()
        torch.manual_seed(20000+seed)
        self.phi=nn.Sequential(nn.Linear(128,128),nn.SiLU(),nn.Linear(128,128))
    def forward(self,x,mask):
        return self.head((self.phi(x)*mask[:,:,None]).sum(1)).squeeze(-1)


def fit_readout(packed,arm,enc_seed,head_seed,args,folder,cache_path):
    model=Readout(head_seed).to(args.device)
    reference=Readout(head_seed).to(args.device)
    assert all(torch.equal(v,reference.state_dict()[k]) for k,v in model.state_dict().items())
    del reference
    assert sum(p.numel() for p in model.parameters())==49665
    seed_all(head_seed+30000)
    optimizer=torch.optim.AdamW(model.parameters(),lr=.001,weight_decay=1e-5)
    generator=torch.Generator().manual_seed(head_seed+40000)
    y=packed['train']['y'];mean=y.mean();std=y.std(unbiased=False)
    best=float('inf');best_epoch=-1;state=None;history=[];started=time.perf_counter()
    def evaluate(split):
        model.eval();x,mask=packed[split][arm]
        with torch.no_grad():
            preds=torch.cat([model(x[i:i+128],mask[i:i+128]) for i in range(0,len(x),128)])*std+mean
        return float((preds-packed[split]['y']).square().mean().sqrt()),preds
    x,mask=packed['train'][arm]
    for epoch in range(args.epochs):
        model.train()
        for idx in torch.randperm(len(x),generator=generator).split(128):
            idx=idx.to(args.device);optimizer.zero_grad(set_to_none=True)
            loss=(model(x[idx],mask[idx])-(y[idx]-mean)/std).square().mean()
            assert torch.isfinite(loss)
            loss.backward();nn.utils.clip_grad_norm_(model.parameters(),5);optimizer.step()
        score,_=evaluate('valid');history.append(dict(epoch=epoch+1,valid_rmse=score))
        if score<best:best=score;best_epoch=epoch;state=copy.deepcopy(model.state_dict())
        if epoch==0 or (epoch+1)%25==0:
            print(f'Encoder {enc_seed} {arm} head {head_seed}: epoch {epoch+1}, best valid {best:.5f}',flush=True)
        if epoch-best_epoch>=args.patience:break
    model.load_state_dict(state)
    valid,vp=evaluate('valid');test,tp=evaluate('test')
    row=dict(encoder_seed=enc_seed,head_seed=head_seed,arm=arm,valid_rmse=valid,test_rmse=test,
             best_epoch=best_epoch+1,epochs_ran=len(history),parameters=49665,
             train_phi_rows=int(mask.sum()),train_padded_rows=int(mask.numel()),
             seconds=time.perf_counter()-started,atom_cache_sha256=sha(cache_path))
    name=f'{arm}_head{head_seed}'
    torch.save(dict(state_dict={k:v.cpu() for k,v in state.items()},metadata=row,history=history,
                    target_mean=float(mean),target_std=float(std)),folder/(name+'.pt'))
    np.savez(folder/(name+'_predictions.npz'),valid=vp.cpu().numpy(),test=tp.cpu().numpy(),
             valid_ids=packed['valid']['ids'],test_ids=packed['test']['ids'])
    print(json.dumps(row),flush=True)
    return row


def summarize(results,output):
    means=[]
    for seed in sorted({r['encoder_seed'] for r in results}):
        for arm in ARMS:
            rows=[r for r in results if r['encoder_seed']==seed and r['arm']==arm]
            means.append(dict(encoder_seed=seed,arm=arm,head_count=len(rows),
                              valid_rmse=float(np.mean([r['valid_rmse'] for r in rows])),
                              test_rmse=float(np.mean([r['test_rmse'] for r in rows]))))
    save_json(output/'per_encoder_means.json',means)
    comparisons=[]
    for method in ARMS[1:]:
        for seed in sorted({r['encoder_seed'] for r in results}):
            deltas=[]
            for row in [r for r in results if r['encoder_seed']==seed and r['arm']==method]:
                ref=next(r for r in results if r['encoder_seed']==seed and r['head_seed']==row['head_seed'] and r['arm']=='A2')
                deltas.append(dict(head_seed=row['head_seed'],valid_delta=row['valid_rmse']-ref['valid_rmse'],
                                   test_delta=row['test_rmse']-ref['test_rmse']))
            comparisons.append(dict(method=method,encoder_seed=seed,paired_head_differences=deltas,
                                     mean_valid_delta=float(np.mean([d['valid_delta'] for d in deltas])),
                                     mean_test_delta=float(np.mean([d['test_delta'] for d in deltas]))))
    save_json(output/'comparisons.json',comparisons)
    with (output/'per_run.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(results[0]));writer.writeheader();writer.writerows(results)
    lines=['# 普通 GINE + 冻结 Motif 读出：Lipo','',
           '原始原子/键输入，无扩散或其他预训练。3个独立Encoder初始化，各3个配对head seeds；同一scaffold split。',
           '表中先对每个Encoder的heads取均值，再对独立Encoder取均值±样本标准差。','',
           '|读出|验证 RMSE|测试 RMSE|','|---|---:|---:|']
    for arm in ARMS:
        vals=[]
        for key in ('valid_rmse','test_rmse'):
            a=np.array([r[key] for r in means if r['arm']==arm]);vals.append(f'{a.mean():.5f} ± {a.std(ddof=1) if len(a)>1 else 0:.5f}')
        lines.append(f'|{arm}|{vals[0]}|{vals[1]}|')
    lines+=['','|分组 − A2|验证差值|测试差值|测试改善的独立Encoder数|','|---|---:|---:|---:|']
    for method in ARMS[1:]:
        rows=[r for r in comparisons if r['method']==method]
        lines.append(f"|{method}|{np.mean([r['mean_valid_delta'] for r in rows]):+.5f}|{np.mean([r['mean_test_delta'] for r in rows]):+.5f}|{sum(r['mean_test_delta']<0 for r in rows)}/{len(rows)}|")
    lines+=['','差值为负表示分组更好。所有原子缓存共用同一validation-best Encoder；readout参数均为49665。',
            '只有一个任务、一个划分，不支持跨任务/划分稳定性结论；9个head运行不是9个独立Encoder。',
            '详细配对差值、各Encoder均值、检查点历史、预测行ID及哈希均保留。未修改原始提取规则，未覆盖原子补齐仅属于读出适配。']
    (output/'RESULTS.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--dataset',type=Path,default=ROOT/'datasets/lipo')
    p.add_argument('--output',type=Path,default=HERE/'results')
    p.add_argument('--device',default='cuda')
    p.add_argument('--encoder-seeds',type=int,nargs='+',default=[0,1,2])
    p.add_argument('--head-seeds',type=int,nargs='+',default=[0,1,2])
    p.add_argument('--epochs',type=int,default=200)
    p.add_argument('--patience',type=int,default=30)
    p.add_argument('--smoke',action='store_true')
    args=p.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    if (args.output/'manifest.json').exists():raise FileExistsError('Preserve existing run; choose a new output')
    torch.set_num_threads(4)
    splits,groups,identity=data_inputs(args)
    if args.smoke:
        splits={k:v[:16] for k,v in splits.items()};args.encoder_seeds=[0];args.head_seeds=[0];args.epochs=2
    manifest=dict(identity=identity,protocol_sha256=sha(HERE/'PROTOCOL.md'),script_sha256=sha(Path(__file__)),
                  encoder_seeds=args.encoder_seeds,head_seeds=args.head_seeds,epochs=args.epochs,
                  patience=args.patience,smoke=args.smoke,device=args.device,torch=torch.__version__)
    save_json(args.output/'manifest.json',manifest)
    results=[];encoders=[]
    for seed in args.encoder_seeds:
        folder=args.output/f'encoder{seed}'
        encoder,checkpoint,meta=fit_encoder(splits,seed,args,folder)
        caches,path=cache_atoms(encoder,splits,checkpoint,args,folder)
        del encoder
        encoders.append(dict(**meta,checkpoint_sha256=sha(checkpoint),atom_cache_sha256=sha(path)))
        save_json(args.output/'encoders.json',encoders)
        packed=pack(caches,groups,args.device)
        for head_seed in args.head_seeds:
            for arm in ARMS:
                results.append(fit_readout(packed,arm,seed,head_seed,args,folder,path))
                save_json(args.output/'progress.json',results)
        del packed,caches
        if args.device.startswith('cuda'):torch.cuda.empty_cache()
    summarize(results,args.output)
    save_json(args.output/'complete.json',results)


if __name__=='__main__':main()
