# 普通 GINE 的冻结 Motif 分组读出实验

研究问题：不使用扩散预训练，在同一普通键感知 GNN 的完全相同原子表示上，HMG-MRL/HimNet 的真实分组读出是否优于逐原子非线性读出？

第一批仅 Lipo，复用已核验的4200个分子及原scaffold split。原始 Motif 数据来自 `motif_structure_audit_20261014/outputs/verified_motifs.json`，不重提取、不改规则；未覆盖原子在读出适配器中补singleton，并在补齐后以覆盖次数c_i归一化。HMG-MRL与HimNet分别运行。

先从随机初始化训练3个普通GINE Encoder（seeds 0,1,2）。Encoder输入为原始RDKit原子/化学键分类特征：原子序数、度、形式电荷、手性、杂化、氢数、芳香性、是否在环；键类型、立体类型、共轭、是否在环。类别越界报错，不能悄悄截断。全部特征均为原结构确定，不使用预训练、扩散特征或分子描述符。

Encoder为4层、hidden=128；分类特征embedding求和；每层GINEConv（train_eps=True，MLP为Linear→SiLU→Linear），LayerNorm、SiLU；中间层dropout=0.1。监督基准使用普通原子Sum和Linear(128,128)→SiLU→Dropout(0.1)→Linear(128,1)预测头。各Encoder以验证RMSE选best checkpoint，baseline测试标签不用于选模。基准头只用于训练Encoder，不作为冻结读出容量对照。

每个validation-best Encoder完全冻结、eval、FP32缓存一次原子表示。冻结读出head seeds为0,1,2，主要比较三组：

- A2：Sum_i phi(h_i) → head。
- A1-HimNet：Sum_M phi(Sum_i∈M h_i/c_i) → head。
- A1-HMG-MRL：相同公式，换成HMG-MRL分组。

phi固定为Linear(128,128)→SiLU→Linear(128,128)，head固定为Linear(128,128)→SiLU→Dropout(0.1)→Linear(128,1)。每组trainable=49665。相同head seed下初始化权重相同、训练分子顺序相同。无内部Motif GNN、跨基序传播、Attention、随机分组或联合尺度分支。

Encoder和冻结读出都使用AdamW lr=0.001、weight_decay=1e-5、clip_grad_norm=5，最多200epochs、patience=30。Encoder batch=64，冻结读出batch=128。目标仅按训练集均值、标准差缩放。测试仅评价validation-best冻结读出模型，不调参、不选分组。

共3次Encoder训练、27次冻结读出训练。报告全部配对差值及每个Encoder内3个head seed的均值，再对3个独立Encoder均值汇总；不能将9个heads视作9次独立Encoder或独立数据划分。仍只有一个任务和一个split，不声称跨任务/跨split稳定。

记录数据/结构/源码/Encoder/缓存SHA256、原始原子序号与分子行ID、参数、实际phi行数、padding行数和耗时。复核分组总和守恒、缓存图级Sum与原子Sum一致、初始化匹配、Encoder冻结无梯度、validation-best选择和预测行对齐。原结构文件和以前的扩散实验均不改动。
