"""Show per-encoder paired differences without treating heads as independent encoders."""
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

out=Path(__file__).resolve().parent/'results'
rows=json.loads((out/'comparisons.json').read_text(encoding='utf-8'))
fig,axes=plt.subplots(1,2,figsize=(10,4),sharey=True)
methods=('A1-HimNet','A1-HMG-MRL')
colors=('#2563eb','#d97706')
for axis,key,title in zip(axes,('valid_delta','test_delta'),('Validation','Test')):
    axis.axhline(0,color='#333333',lw=1)
    for mi,(method,color) in enumerate(zip(methods,colors)):
        for row in [r for r in rows if r['method']==method]:
            x=row['encoder_seed']+(-.12 if mi==0 else .12)
            values=[d[key] for d in row['paired_head_differences']]
            axis.scatter(x+np.linspace(-.035,.035,len(values)),values,s=24,alpha=.55,color=color)
            axis.scatter([x],[np.mean(values)],s=65,marker='s',color=color,
                         label=method if row['encoder_seed']==0 else None)
    axis.set_xticks([0,1,2],['Encoder 0','Encoder 1','Encoder 2'])
    axis.set_title(title);axis.grid(axis='y',alpha=.2)
axes[0].set_ylabel('Paired RMSE difference: grouped readout - A2\nNegative values favor grouped readout')
axes[1].legend(frameon=False)
fig.suptitle('Ordinary GINE, same Lipo split; dots = paired heads, squares = encoder means',fontsize=10)
fig.tight_layout()
fig.savefig(out/'paired_differences.png',dpi=180)
plt.close(fig)
print(out/'paired_differences.png')
