"""Meaningful checks for bond-aware encoding and graph batching."""
import torch
from torch_geometric.data import Batch
from run import graph,Encoder,Readout,seed_all

seed_all(9)
g=graph('CC(=O)O',0,1.)
model=Encoder().eval()
batch=Batch.from_data_list([g])
with torch.no_grad():
    first=model(batch)
    changed=batch.clone();changed.edge_attr[:,0]=1
    assert not torch.allclose(first,model(changed)), 'Encoder must use bond types'
    other=graph('c1ccccc1',1,2.)
    together=model(Batch.from_data_list([g,other]))[:g.num_nodes]
    torch.testing.assert_close(first,together,atol=1e-5,rtol=1e-5)
    perm=torch.tensor([2,0,3,1]);inverse=torch.argsort(perm)
    reordered=g.clone();reordered.x=g.x[perm];reordered.edge_index=inverse[g.edge_index]
    torch.testing.assert_close(model(Batch.from_data_list([reordered]))[inverse],first,atol=1e-5,rtol=1e-5)
    isolated=graph('O.O',2,0.)
    assert model(Batch.from_data_list([isolated])).shape==(2,128)
readout=Readout(0).eval()
x=torch.randn(1,3,128)
mask=torch.ones(1,3,dtype=torch.bool)
pad=torch.cat((x,torch.zeros(1,5,128)),1)
padmask=torch.tensor([[True]*3+[False]*5])
torch.testing.assert_close(readout(x,mask),readout(pad,padmask))
duplicate=Readout(0)
assert all(torch.equal(v,duplicate.state_dict()[k]) for k,v in readout.state_dict().items())
model.train();loss=model(batch).square().mean();loss.backward()
assert model.bond.embeddings[0].weight.grad is not None
assert all(conv.nn[0].weight.grad is not None for conv in model.convs)
print('PASS: bond sensitivity, batch independence, atom permutation equivariance, bondless graph, padding, paired initialization, all-layer gradients')
