"""Label-blind constrained membership randomization; no model training."""
from collections import Counter,defaultdict
import hashlib
import json
from pathlib import Path
import random
import time
from rdkit import Chem

HERE=Path(__file__).resolve().parent
SOURCE=HERE.parent/'motif_structure_audit_20261014/outputs/verified_motifs.json'
DRAWS=(0,1,2)
PROPOSALS=512


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def mask_of(atoms):
    return sum(1<<i for i in atoms)


def popcount(mask):
    return bin(mask).count('1')


def atoms_of(mask):
    result=[]
    while mask:
        b=mask&-mask;result.append(b.bit_length()-1);mask-=b
    return result


def connected(mask,neighbors):
    seen=mask&-mask;front=seen
    while front:
        nxt=0
        while front:
            bit=front&-front;front-=bit
            nxt|=neighbors[bit.bit_length()-1]
        front=nxt&mask&~seen;seen|=front
    return seen==mask


def randomize(groups,n,neighbors,seed):
    masks=[mask_of(g) for g in groups];original=masks.copy()
    memberships=[set() for _ in range(n)]
    for k,g in enumerate(groups):
        for a in g:memberships[a].add(k)
    buckets=defaultdict(list)
    for a,member in enumerate(memberships):buckets[len(member)].append(a)
    pairs=[bucket for bucket in buckets.values() if len(bucket)>=2]
    rng=random.Random(seed);accepted=0;tested=0
    # The full collection undergoes a common atom permutation. Group cardinalities,
    # all pairwise intersections and each atom's coverage count remain unchanged.
    for _ in range(PROPOSALS):
        if not pairs:break
        bucket=rng.choice(pairs);a,b=rng.sample(bucket,2)
        affected=memberships[a]^memberships[b]
        if not affected:continue
        toggle=(1<<a)|(1<<b)
        proposal={k:masks[k]^toggle for k in affected};tested+=1
        if not all(connected(g,neighbors) for g in proposal.values()):continue
        for k,g in proposal.items():masks[k]=g
        memberships[a],memberships[b]=memberships[b],memberships[a]
        accepted+=1
    original_family=set(original);new_family=set(masks)
    assert [popcount(g) for g in masks]==[popcount(g) for g in original]
    assert all(connected(g,neighbors) for g in masks)
    # Full overlap matrix, not only aggregate overlap rate.
    assert all(popcount(a&b)==popcount(c&d)
               for i,(a,c) in enumerate(zip(original,masks))
               for b,d in zip(original[i+1:],masks[i+1:]))
    for atom in range(n):
        assert sum(bool(g&(1<<atom)) for g in original)==sum(bool(g&(1<<atom)) for g in masks)
    changed=sum(g not in original_family for g in masks)
    return [atoms_of(g) for g in masks],dict(accepted_swaps=accepted,tested_swaps=tested,
        changed_groups=changed,total_groups=len(groups),family_changed=original_family!=new_family,
        group_change_fraction=changed/len(groups))


def main():
    out=HERE/'controls';out.mkdir(parents=True,exist_ok=True)
    if (out/'manifest.json').exists():raise FileExistsError('Preserve generated controls')
    records=json.loads(SOURCE.read_text(encoding='utf-8'))
    original_hash=sha(SOURCE)
    families=[];stats=defaultdict(Counter);neighbor_cache={};start=time.monotonic()
    for ri,r in enumerate(records):
        idx=r['source_row'];n=len(r['atoms'])
        if idx not in neighbor_cache:
            neighbors=[0]*n
            for b in r['bonds']:
                a,c=b['begin'],b['end'];neighbors[a]|=1<<c;neighbors[c]|=1<<a
            neighbor_cache[idx]=neighbors
        neighbors=neighbor_cache[idx]
        groups=[g['atoms'] for g in r['motifs']]+[[i] for i in r['uncovered_atoms']]
        assert all(connected(mask_of(g),neighbors) for g in groups)
        for draw in DRAWS:
            seed=202610150000+idx*10+draw+(100000 if r['method']=='HMG-MRL' else 0)
            randomized,info=randomize(groups,n,neighbors,seed)
            st=stats[(r['method'],draw)]
            st.update(molecules=1,changed_molecules=int(info['family_changed']),
                      unchanged_molecules=int(not info['family_changed']),
                      groups=info['total_groups'],changed_groups=info['changed_groups'],
                      accepted_swaps=info['accepted_swaps'],tested_swaps=info['tested_swaps'])
            families.append(dict(source_row=idx,method=r['method'],draw=draw,seed=seed,
                                 groups=randomized,coverage=[max(1,c) for c in r['original_coverage_counts']],
                                 **info))
        if (ri+1)%1000==0:print(f'Audited {ri+1}/8400 chemical families, 3 null draws each',flush=True)
    assert sha(SOURCE)==original_hash
    summary=[]
    for (method,draw),st in sorted(stats.items()):
        summary.append(dict(method=method,draw=draw,**st,
                            changed_molecule_fraction=st['changed_molecules']/st['molecules'],
                            changed_group_fraction=st['changed_groups']/st['groups']))
    manifest=dict(source_sha256=original_hash,script_sha256=sha(Path(__file__)),draws=list(DRAWS),
                  proposals_per_family=PROPOSALS,labels_accessed=False,training=False,
                  constraints=['exact_group_sizes','exact_group_count','exact_per_atom_coverage',
                               'exact_pairwise_overlap_matrix','all_groups_connected'],
                  not_uniform_sampling=True,identity_fallback_explicit=True,seconds=time.monotonic()-start)
    for name,value in [('groups.json',families),('summary.json',summary),('manifest.json',manifest)]:
        (out/name).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
