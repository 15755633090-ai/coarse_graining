"""Unlabeled mechanistic witness: identical local COOH inputs, different surroundings."""
import json
from pathlib import Path
import torch
from torch_geometric.data import Batch
from rdkit import Chem
from run_stages import HERE,VALID,local_graphs
from run import graph,Baseline,sha

smiles=['CC(=O)O','CCC(=O)O']
pattern=Chem.MolFromSmarts('[CX3](=[OX1])[OX2H1]')
graphs={i:graph(s,i,0.) for i,s in enumerate(smiles)}
records=[];members=[]
for i,s in enumerate(smiles):
    mol=Chem.MolFromSmiles(s);atoms=sorted(mol.GetSubstructMatch(pattern));assert len(atoms)==3
    members.append(atoms)
    counts=[int(a in atoms) for a in range(mol.GetNumAtoms())]
    boundary=[b.GetIdx() for b in mol.GetBonds() if (b.GetBeginAtomIdx() in atoms)!=(b.GetEndAtomIdx() in atoms)]
    records.append(dict(source_row=i,method='COOH-witness',original_coverage_counts=counts,
                        motifs=[dict(atoms=atoms,boundary_bonds=boundary)],uncovered_atoms=[]))
items,_=local_graphs(graphs,records)
assert torch.equal(items[0].x,items[1].x)
assert torch.equal(items[0].edge_index,items[1].edge_index)
assert torch.equal(items[0].edge_attr,items[1].edge_attr)
encoders=json.loads((VALID/'encoders.json').read_text(encoding='utf-8'))
torch.set_num_threads(4);torch.backends.cuda.matmul.allow_tf32=False
result=[]
for enc in encoders:
    path=Path(enc['artifact_dir'])/'encoder_best.pt';assert sha(path)==enc['checkpoint_sha256']
    model=Baseline().eval().requires_grad_(False)
    model.load_state_dict(torch.load(path,map_location='cpu',weights_only=True)['state_dict'])
    with torch.no_grad():
        local=model.encoder(Batch.from_data_list(items))
        torch.testing.assert_close(local[:3],local[3:],rtol=1e-6,atol=1e-6)
        batch=Batch.from_data_list(list(graphs.values()));full=model.encoder(batch)
        a=full[members[0]];b=full[batch.ptr[1]+torch.tensor(members[1])]
        result.append(dict(split_name=enc['split_name'],encoder_seed=enc['seed'],
                           local_max_abs_difference=float((local[:3]-local[3:]).abs().max()),
                           full_atom_state_difference_norm=float((a-b).norm()),
                           full_pooled_difference_norm=float((a.sum(0)-b.sum(0)).norm())))
proof=dict(molecules=smiles,region='COOH',original_atom_features_identical=True,
           internal_edge_indices_and_features_identical=True,labels_used=False,new_training=False,
           all_local_states_equal=True,encoder_results=result,
           interpretation='Local inputs cannot distinguish these surrounding chains; Full state differences demonstrate context sensitivity, not property-prediction benefit.')
(HERE/'context_pair_check.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(proof,ensure_ascii=False,indent=2))
