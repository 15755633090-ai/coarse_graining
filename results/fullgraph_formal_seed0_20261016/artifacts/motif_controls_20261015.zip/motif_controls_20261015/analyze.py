"""Encoder-level intervals for conditional membership nulls and boundary messages."""
import json
from pathlib import Path
import csv
import gzip
import hashlib
from collections import defaultdict
import numpy as np
from scipy.stats import t

HERE=Path(__file__).resolve().parent
OUT=HERE/'results'
VALID=HERE.parent/'gine_motif_validation_20261014/results'


def ci(values):
    a=np.asarray(values,dtype=float);assert len(a)==5
    mean=float(a.mean());sd=float(a.std(ddof=1));half=float(t.ppf(.975,4)*sd/np.sqrt(5))
    return dict(mean=mean,sd=sd,lower=mean-half,upper=mean+half,n_encoders=5)


def main():
    rows=json.loads((OUT/'complete.json').read_text(encoding='utf-8'));assert len(rows)==240
    reference=json.loads((VALID/'complete.json').read_text(encoding='utf-8'))
    refs={(r['split_name'],r['encoder_seed'],r['head_seed'],r['arm']):r for r in reference}
    controls=json.loads((HERE/'controls/groups.json').read_text(encoding='utf-8'))
    changed={(r['source_row'],r['method'],r['draw']):r['family_changed'] for r in controls}
    labels_path=HERE.parent/'datasets/lipo/raw/graph-label.csv.gz'
    reference_manifest=json.loads((VALID/'manifest.json').read_text(encoding='utf-8'))
    expected=reference_manifest['identity']['data_sha256'][str(labels_path)]
    assert hashlib.sha256(labels_path.read_bytes()).hexdigest()==expected
    with gzip.open(labels_path,'rt',encoding='utf-8') as f:
        labels=np.asarray([float(r[0]) for r in csv.reader(f)],dtype=np.float32)
    assert len(labels)==4200 and np.isfinite(labels).all()
    individual=[]
    for r in rows:
        ref=refs[(r['split_name'],r['encoder_seed'],r['head_seed'],r['arm'])]
        assert r['atom_cache_sha256']==ref['atom_cache_sha256']
        folder=Path(r['artifact_dir']);base=Path(ref['artifact_dir'])
        name=f"{r['arm']}_head{r['head_seed']}_predictions.npz"
        row={k:r[k] for k in ('stage','method','draw','split_name','encoder_seed','head_seed')}
        sign=-1 if r['stage']=='null' else 1
        row.update(valid_delta=sign*(r['valid_rmse']-ref['valid_rmse']),
                   test_delta=sign*(r['test_rmse']-ref['test_rmse']),
                   experimental_test_rmse=r['test_rmse'],chemical_full_test_rmse=ref['test_rmse'])
        if r['stage']=='null':
            with np.load(folder/name) as pred,np.load(base/name) as full:
                assert np.array_equal(pred['test_ids'],full['test_ids'])
                mask=np.array([changed[(int(i),r['method'],r['draw'])] for i in pred['test_ids']],dtype=bool)
                row['changed_test_molecules']=int(mask.sum())
                if mask.any():
                    y=labels[pred['test_ids'][mask]]
                    chemical=float(np.sqrt(np.mean((full['test'][mask]-y)**2)))
                    null=float(np.sqrt(np.mean((pred['test'][mask]-y)**2)))
                    row['changed_subset_test_delta']=chemical-null
                else:row['changed_subset_test_delta']=None
        individual.append(row)
    per_encoder=[];intervals=[]
    for stage in ('null','context'):
        for split in ('original','new_scaffold'):
            for method in ('HimNet','HMG-MRL'):
                family=[]
                for seed in range(5):
                    block=[r for r in individual if r['stage']==stage and r['split_name']==split and r['method']==method and r['encoder_seed']==seed]
                    assert len(block)==(9 if stage=='null' else 3)
                    m=dict(stage=stage,split_name=split,method=method,encoder_seed=seed,
                           valid_delta=float(np.mean([r['valid_delta'] for r in block])),
                           test_delta=float(np.mean([r['test_delta'] for r in block])))
                    if stage=='null':
                        assert all(r['changed_subset_test_delta'] is not None for r in block)
                        m['changed_subset_test_delta']=float(np.mean([r['changed_subset_test_delta'] for r in block]))
                    per_encoder.append(m);family.append(m)
                interval=dict(stage=stage,split_name=split,method=method,
                              validation=ci([r['valid_delta'] for r in family]),
                              test=ci([r['test_delta'] for r in family]))
                if stage=='null':interval['changed_subset']=ci([r['changed_subset_test_delta'] for r in family])
                intervals.append(interval)
    for name,data in [('individual_differences.json',individual),('per_encoder_differences.json',per_encoder),('intervals.json',intervals)]:
        (OUT/name).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    with (OUT/'per_run.csv').open('w',encoding='utf-8-sig',newline='') as f:
        keys=sorted(set().union(*(r.keys() for r in individual)))
        writer=csv.DictWriter(f,fieldnames=keys);writer.writeheader();writer.writerows(individual)
    summarize_diagnostics()
    report(intervals)
    print(json.dumps(intervals,ensure_ascii=False,indent=2))


def summarize_diagnostics():
    buckets=defaultdict(list)
    for path in (OUT/'context').glob('*/encoder*/context_diagnostics.json'):
        split=path.parent.parent.name;seed=int(path.parent.name.replace('encoder',''))
        data=json.loads(path.read_text(encoding='utf-8'))
        for method in ('HimNet','HMG-MRL'):
            for stratum,fn in [('boundary',lambda r:r['boundary_bonds']>0),('no_boundary',lambda r:r['boundary_bonds']==0),
                                ('multiatom_boundary',lambda r:r['atoms']>1 and r['boundary_bonds']>0)]:
                block=[r for r in data if r['method']==method and fn(r)]
                buckets[(split,method,stratum)].append(dict(encoder_seed=seed,groups=len(block),
                    mean_cosine=float(np.mean([r['cosine'] for r in block])) if block else None,
                    mean_relative_l2=float(np.mean([r['relative_l2'] for r in block])) if block else None))
    records=[dict(split_name=k[0],method=k[1],stratum=k[2],encoder_statistics=v) for k,v in buckets.items()]
    (OUT/'diagnostic_summary.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')


def report(intervals):
    lines=['# 化学成员分配与局部上下文对照','',
           '复用Lipo两个划分×5个冻结GINE Encoder、每个3个配对head种子；未重训Encoder。新增180次成员扰动读出和60次局部消息读出，模型/优化/选模协议不变。','',
           '## 化学成员分配与结构匹配扰动','',
           '差值=化学分组RMSE−非化学扰动分组RMSE，负值表示化学成员分配更好。每个Encoder先平均3 draws×3 heads，再在5个Encoder间计算点态95% t区间。','',
           '|划分|方法|测试差值均值|95%区间|仅成员分组改变的测试子集差值|子集95%区间|','|---|---|---:|---|---:|---|']
    for r in [r for r in intervals if r['stage']=='null']:
        a=r['test'];b=r['changed_subset']
        lines.append(f"|{r['split_name']}|{r['method']}|{a['mean']:+.5f}|[{a['lower']:+.5f}, {a['upper']:+.5f}]|{b['mean']:+.5f}|[{b['lower']:+.5f}, {b['upper']:+.5f}]|")
    lines+=['','严格匹配组大小、组数、逐原子覆盖次数、两两交叠数量和连通性；但不是所有匹配分组上的均匀采样，模板本身仍来自原化学划分。HimNet约71%分子/38%组改变，HMG-MRL约54%分子/10%组改变。未改变的分组不冒充随机化成功，子集只按结构变化确定，不能按预测挑选。',
            '该对照检验特定约束下化学成员分配的价值，不证明化学分组优于所有其他分组，也不代表完全移除了化学先验。','',
            '## 限制Motif内部传播','',
            '差值=Local RMSE−Full RMSE，正值表示在当前冻结权重下移除外部消息后预测变差。成员/原始特征/Encoder权重/读出均保持一致。','',
            '|划分|方法|测试差值均值|95%区间|','|---|---|---:|---|']
    for r in [r for r in intervals if r['stage']=='context']:
        a=r['test'];lines.append(f"|{r['split_name']}|{r['method']}|{a['mean']:+.5f}|[{a['lower']:+.5f}, {a['upper']:+.5f}]|")
    lines+=['','Local只对原始真实Motif执行诱导子图GINE，未覆盖补齐singleton保留Full表示。无边界片段的Local/Full向量一致性已检查。所有向量差异诊断见diagnostic_summary.json。',
            'HMG-MRL有重叠Motif：某个Motif的外部关系可能在另一个Motif内部保留。因此这是逐Motif的外部消息限制，不是把整分子的所有跨片段关系彻底删除。固定分组本身也不等于无上下文。',
            '原始degree/氢数/ring等特征仍含部分环境信息，故这是跨边界消息消融，不是彻底无上下文输入。Encoder在完整图上训练，局部计算可能产生分布偏移，性能变化不能全部归因为信息损失；不能泛化为所有局部GNN必然更差。向量变化也不等同于性质收益。','',
            '## 分析边界','',
            '仅报告区间，不设最小有意义改善阈值。所有区间为小n=5 Encoder的点态t区间，依赖近似正态假设，未作多重比较校正。heads、draws、重叠分子划分不当作独立总体样本，区间只反映固定划分下的初始化/训练随机性。',
            '源代码、结构、缓存和预测行ID核验见verification.json。完成本轮固定预算后不自动追加实验。']
    witness=HERE/'context_pair_check.json'
    if witness.exists():
        w=json.loads(witness.read_text(encoding='utf-8'))
        different=sum(r['full_atom_state_difference_norm']>1e-6 for r in w['encoder_results'])
        lines+=['','## 无标签上下文区分检查','',
                '乙酸 CC(=O)O 与丙酸 CCC(=O)O 的COOH区域，原始原子特征、内部边索引和边特征逐项相同。',
                f'局部编码在全部{len(w["encoder_results"])}个Encoder上给出相同状态；Full编码在{different}个上给出不同状态。该检查没有训练新模型或使用性质标签。',
                '这给出局部限制丢失某些外部环境区分能力的具体例子，不单独证明这些信息对性质预测有用。固定Motif成员本身不等于忽略上下文，当前Full方案本就包含外部消息。']
    raw=json.loads((OUT/'complete.json').read_text(encoding='utf-8'))
    lines+=['','## 固定训练预算的使用','',
            '|阶段|方法|运行数|达到200epoch上限|','|---|---|---:|---:|']
    for stage in ('null','context'):
        for method in ('HimNet','HMG-MRL'):
            block=[r for r in raw if r['stage']==stage and r['method']==method]
            lines.append(f"|{stage}|{method}|{len(block)}|{sum(r['epochs_ran']>=200 for r in block)}|")
    lines+=['','相同预算不保证相同收敛程度。Local的差异也可能包含优化难度和输入分布偏移，不能据此严格分解信息损失的因果贡献。完整逐epoch历史保留。']
    audit=HERE/'controls/fragment_type_audit.json'
    if audit.exists():
        data=json.loads(audit.read_text(encoding='utf-8'))
        ratios=[r['canonical_fragment_multiset_changed']/r['index_family_changed'] for r in data['summary']]
        lines+=['','## 补充的无标签结构审计','',
                f'在成员分组改变的分子中，{min(ratios):.2%}以上同时改变了规范片段字符串的多重集。这是描述性的结构检查，不是官能团语义判定；没有据此选择或修改控制组，也没有改变预先定义的测试子集。详见controls/fragment_type_audit.json。']
    (OUT/'RESULTS.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')


def plot(rows):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(1,2,figsize=(12,4.8))
    for axis,stage,title,label in zip(axes,('null','context'),
            ('Chemical vs constrained membership perturbations','Removing cross-Motif messages'),
            ('Chemical - null RMSE (negative favors chemical)',
             'Local - Full RMSE (positive favors external messages)')):
        block=[r for r in rows if r['stage']==stage]
        axis.axvline(0,color='#333',lw=1)
        names=[]
        for i,r in enumerate(block):
            s=r['test'];color='#2563eb' if r['method']=='HimNet' else '#d97706'
            axis.errorbar(s['mean'],i,xerr=[[s['mean']-s['lower']],[s['upper']-s['mean']]],
                          fmt='o',capsize=4,color=color)
            names.append(r['split_name']+' / '+r['method'])
        axis.set_yticks(range(4),names);axis.invert_yaxis()
        axis.set_title(title,fontsize=10);axis.set_xlabel(label,fontsize=9);axis.grid(axis='x',alpha=.2)
    fig.suptitle('Frozen GINE; pointwise 95% t intervals over 5 encoder means per split',fontsize=11)
    fig.tight_layout();fig.savefig(OUT/'intervals.png',dpi=180);plt.close(fig)


if __name__=='__main__':main()
