"""Descriptive, label-blind check of fragment-type changes; never select controls."""
import json
from collections import Counter,defaultdict
from rdkit import Chem
from audit_controls import HERE,SOURCE,sha

source=json.loads(SOURCE.read_text(encoding='utf-8'))
original={(r['source_row'],r['method']):r for r in source}
controls=json.loads((HERE/'controls/groups.json').read_text(encoding='utf-8'))
last=None;mol=None;cache={};counts=defaultdict(Counter)
for control in controls:
    idx=control['source_row'];r=original[(idx,control['method'])]
    if idx!=last:
        mol=Chem.MolFromSmiles(r['smiles']);cache={};last=idx
    def signature(atoms):
        key=tuple(atoms)
        if key not in cache:
            cache[key]=Chem.MolFragmentToSmiles(mol,atomsToUse=atoms,canonical=True,isomericSmiles=True)
        return cache[key]
    chemical=[g['atoms'] for g in r['motifs']]+[[i] for i in r['uncovered_atoms']]
    a=Counter(signature(g) for g in chemical)
    b=Counter(signature(g) for g in control['groups'])
    st=counts[(control['method'],control['draw'])]
    st.update(molecules=1,index_family_changed=int(control['family_changed']),
              canonical_fragment_multiset_changed=int(a!=b))
summary=[dict(method=k[0],draw=k[1],**v) for k,v in counts.items()]
proof=dict(source_sha256=sha(SOURCE),controls_sha256=sha(HERE/'controls/groups.json'),
           labels_used=False,controls_selected_or_modified=False,
           note='Canonical fragment strings describe atom/bond substructures, not validated functional-group semantic labels. This descriptive audit does not change the prespecified changed-subset definition.',
           summary=summary)
(HERE/'controls/fragment_type_audit.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
