# 两阶段固定验证

协议见 `PROTOCOL.md`。在工作区根目录使用 `C:/Users/12775/miniconda3/envs/polyolefin_ml/python.exe`。

```powershell
& C:/Users/12775/miniconda3/envs/polyolefin_ml/python.exe coarse_graining1/motif_controls_20261015/audit_controls.py
& C:/Users/12775/miniconda3/envs/polyolefin_ml/python.exe coarse_graining1/motif_controls_20261015/normalize_controls.py
& C:/Users/12775/miniconda3/envs/polyolefin_ml/python.exe coarse_graining1/motif_controls_20261015/check_context.py
& C:/Users/12775/miniconda3/envs/polyolefin_ml/python.exe coarse_graining1/motif_controls_20261015/run_stages.py
& C:/Users/12775/miniconda3/envs/polyolefin_ml/python.exe coarse_graining1/motif_controls_20261015/analyze.py
& C:/Users/12775/miniconda3/envs/polyolefin_ml/python.exe coarse_graining1/motif_controls_20261015/plot_results.py
& C:/Users/12775/miniconda3/envs/polyolefin_ml/python.exe coarse_graining1/motif_controls_20261015/verify.py
```

已有控制组不重新生成。若训练中断，`run_stages.py --resume`检查哈希后复用已完成结果。新增180次受约束成员扰动读出，之后60次局部上下文读出；不训练新Encoder，也不新增split。原有90次化学Full/A2读出只引用。

所有文本显式UTF-8。`smoke_context`是无标签小图实现检查，不计入实验结果。结构控制不是均匀全随机分组，严格匹配约束可能导致部分分子保持原分组；比例和子集诊断必须随结果一起报告。Local是固定原始特征下去除外部消息，不是彻底移除一切环境信息，也不把Frozen模型的分布偏移全部解释为结构信息损失。
