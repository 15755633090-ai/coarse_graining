"""Fixed null-membership controls, followed by motif-boundary message ablation."""
import argparse
import json
from pathlib import Path
from types import SimpleNamespace
import sys
import time
import numpy as np
import torch
from torch_geometric.data import Data
from torch_geometric.loader import DataLoader
from torch_geometric.nn import global_add_pool

HERE=Path(__file__).resolve().parent
BASE=HERE.parent/'gine_motif_readout_20261014'
VALID=HERE.parent/'gine_motif_validation_20261014/results'
STRUCT=HERE.parent/'motif_structure_audit_20261014/outputs/verified_motifs.json'
sys.path.insert(0,str(BASE))
from run import sha,save_json,fit_readout,data_inputs,Baseline


def packed_vectors(caches,arm,vectors,device):
    result={}
    for split,cache in caches.items():
        items=[vectors[i] for i in cache['ids']]
        x=torch.zeros(len(items),max(len(v) for v in items),128,device=device)
        mask=torch.zeros(x.shape[:2],dtype=torch.bool,device=device)
        for i,v in enumerate(items):x[i,:len(v)]=v.to(device);mask[i,:len(v)]=True
        result[split]=dict(y=cache['y'].to(device),ids=cache['ids'])
        result[split][arm]=(x,mask)
    return result


def full_atoms(caches):
    return {idx:h for block in caches.values() for idx,h in zip(block['ids'],block['atoms'])}


def local_graphs(graphs,records):
    result=[];meta=[]
    for r in records:
        idx=r['source_row'];g=graphs[idx];n=g.num_nodes
        counts=torch.tensor([max(1,c) for c in r['original_coverage_counts']])
        for k,motif in enumerate(r['motifs']):
            atoms=torch.tensor(motif['atoms'],dtype=torch.long)
            remap=torch.full((n,),-1,dtype=torch.long);remap[atoms]=torch.arange(len(atoms))
            valid=(remap[g.edge_index[0]]>=0)&(remap[g.edge_index[1]]>=0)
            item=Data(x=g.x[atoms],edge_index=remap[g.edge_index[:,valid]],edge_attr=g.edge_attr[valid],
                      coverage=counts[atoms],num_nodes=len(atoms))
            result.append(item)
            meta.append(dict(row=idx,method=r['method'],group=k,atoms=motif['atoms'],
                             counts=counts[atoms],boundary=len(motif['boundary_bonds'])))
    return result,meta


def make_local_vectors(encoder,items,meta,records,caches,device,folder):
    folder.mkdir(parents=True,exist_ok=True)
    full=full_atoms(caches)
    vectors={(r['source_row'],r['method']):[] for r in records}
    diagnostics=[];position=0
    snapshot={k:v.cpu().clone() for k,v in encoder.state_dict().items()}
    with torch.no_grad():
        loader=DataLoader(items,batch_size=256,shuffle=False,num_workers=0)
        for step,batch in enumerate(loader):
            batch=batch.to(device);h=encoder(batch)
            pools=global_add_pool(h/batch.coverage[:,None],batch.batch).cpu()
            for pooled,m in zip(pools,meta[position:position+len(pools)]):
                original=(full[m['row']][m['atoms']]/m['counts'][:,None]).sum(0)
                assert torch.isfinite(pooled).all()
                if m['boundary']==0:
                    torch.testing.assert_close(pooled,original,atol=2e-4,rtol=2e-5)
                vectors[(m['row'],m['method'])].append(pooled)
                cosine=float(torch.nn.functional.cosine_similarity(pooled[None],original[None]))
                relative=float((pooled-original).norm()/original.norm().clamp_min(1e-8))
                diagnostics.append(dict(row=m['row'],method=m['method'],group=m['group'],
                                        atoms=len(m['atoms']),boundary_bonds=m['boundary'],
                                        cosine=cosine,relative_l2=relative))
            position+=len(pools)
            if (step+1)%100==0:print(f'Local context encoded {position}/{len(items)} real motifs',flush=True)
    assert position==len(meta)
    for r in records:
        key=(r['source_row'],r['method']);vs=vectors[key]
        assert len(vs)==len(r['motifs'])
        # Supplemental singletons are not real Motifs: preserve their full-context states.
        vs.extend(full[r['source_row']][i] for i in r['uncovered_atoms'])
        vectors[key]=torch.stack(vs)
    assert all(not p.requires_grad and p.grad is None for p in encoder.parameters())
    assert all(torch.equal(snapshot[k],v.cpu()) for k,v in encoder.state_dict().items())
    torch.save(vectors,folder/'local_vectors.pt')
    save_json(folder/'context_diagnostics.json',diagnostics)
    return vectors


def main():
    p=argparse.ArgumentParser();p.add_argument('--resume',action='store_true');p.add_argument('--device',default='cuda')
    args=p.parse_args();args.epochs=200;args.patience=30
    out=HERE/'results';out.mkdir(exist_ok=True)
    controls_path=HERE/'controls/groups.json'
    controls_manifest=json.loads((HERE/'controls/manifest.json').read_text(encoding='utf-8'))
    validation=json.loads((VALID/'manifest.json').read_text(encoding='utf-8'))
    assert sha(BASE/'run.py')==validation['core_script_sha256']
    assert sha(controls_path)==controls_manifest['groups_sha256']
    assert sha(STRUCT)==controls_manifest['source_sha256']
    assert json.loads((VALID/'verification.json').read_text(encoding='utf-8'))['readout_runs']==90
    encoders=json.loads((VALID/'encoders.json').read_text(encoding='utf-8'))
    controls=json.loads(controls_path.read_text(encoding='utf-8'))
    lookup={(c['source_row'],c['method'],c['draw']):c for c in controls}
    records=json.loads(STRUCT.read_text(encoding='utf-8'))
    original={(r['source_row'],r['method']):[g['atoms'] for g in r['motifs']]+[[i] for i in r['uncovered_atoms']] for r in records}
    manifest=dict(protocol_sha256=sha(HERE/'PROTOCOL.md'),runner_sha256=sha(Path(__file__)),
                  core_sha256=sha(BASE/'run.py'),controls_sha256=sha(controls_path),
                  structure_sha256=sha(STRUCT),reference_sha256=sha(VALID/'complete.json'),
                  encoder_references=encoders,null_draws=[0,1,2],head_seeds=[0,1,2],
                  planned_null_runs=180,planned_context_runs=60,device=args.device,
                  minimum_effect_threshold=None,encoder_training=False)
    mf=out/'manifest.json'
    if mf.exists():
        assert args.resume and json.loads(mf.read_text(encoding='utf-8'))==manifest
    else:save_json(mf,manifest)
    progress=out/'progress.json'
    results=json.loads(progress.read_text(encoding='utf-8')) if args.resume and progress.exists() else []
    torch.set_num_threads(4);torch.backends.cuda.matmul.allow_tf32=False
    # Phase 1: re-read each frozen cache, never train or change its encoder.
    for enc in encoders:
        split=enc['split_name'];seed=enc['seed'];cache_path=Path(enc['artifact_dir'])/'atom_cache.pt'
        assert sha(cache_path)==enc['atom_cache_sha256']
        caches=torch.load(cache_path,map_location='cpu',weights_only=True)['splits'];atoms=full_atoms(caches)
        for method in ('HimNet','HMG-MRL'):
            arm='A1-'+method
            for draw in (0,1,2):
                folder=out/'null'/split/f'encoder{seed}'/method/f'draw{draw}'
                folder.mkdir(parents=True,exist_ok=True)
                vectors={}
                for idx,h in atoms.items():
                    c=lookup[(idx,method,draw)];counts=torch.tensor(c['coverage'])
                    gs=c['groups'];assert len(gs)==len(original[(idx,method)])
                    vectors[idx]=torch.stack([(h[g]/counts[g,None]).sum(0) for g in gs])
                    torch.testing.assert_close(vectors[idx].sum(0),h.sum(0),atol=1e-4,rtol=1e-5)
                packed=packed_vectors(caches,arm,vectors,args.device)
                for head_seed in (0,1,2):
                    if any(r['stage']=='null' and r['split_name']==split and r['encoder_seed']==seed and
                           r['method']==method and r['draw']==draw and r['head_seed']==head_seed for r in results):continue
                    row=fit_readout(packed,arm,seed,head_seed,args,folder,cache_path)
                    results.append(dict(row,stage='null',method=method,draw=draw,split_name=split,
                                        artifact_dir=str(folder),reference_artifact_dir=enc['artifact_dir']))
                    save_json(progress,results)
                    print(f'STAGE null COMPLETE {len(results)}/240 readouts',flush=True)
                del packed,vectors
        del caches,atoms
        if args.device.startswith('cuda'):torch.cuda.empty_cache()
    assert sum(r['stage']=='null' for r in results)==180
    # Phase 2: same motif membership and GNN weights, remove external messages only.
    splits,_,_=data_inputs(SimpleNamespace(dataset=HERE.parent/'datasets/lipo'))
    graphs={int(g.row_id):g for block in splits.values() for g in block}
    items,meta=local_graphs(graphs,records)
    print(f'STAGE context: {len(items)} real Motif graphs; no new GNN training',flush=True)
    for enc in encoders:
        split=enc['split_name'];seed=enc['seed'];reference=Path(enc['artifact_dir'])
        cache_path=reference/'atom_cache.pt';checkpoint=reference/'encoder_best.pt'
        assert sha(checkpoint)==enc['checkpoint_sha256'] and sha(cache_path)==enc['atom_cache_sha256']
        caches=torch.load(cache_path,map_location='cpu',weights_only=True)['splits']
        folder=out/'context'/split/f'encoder{seed}';folder.mkdir(parents=True,exist_ok=True)
        vector_file=folder/'local_vectors.pt'
        if args.resume and vector_file.exists():vectors=torch.load(vector_file,map_location='cpu',weights_only=True)
        else:
            model=Baseline().to(args.device)
            model.load_state_dict(torch.load(checkpoint,map_location='cpu',weights_only=True)['state_dict'])
            encoder=model.encoder.eval().requires_grad_(False)
            vectors=make_local_vectors(encoder,items,meta,records,caches,args.device,folder)
            del model,encoder
        save_json(folder/'cache_manifest.json',dict(encoder_sha256=sha(checkpoint),full_cache_sha256=sha(cache_path),
                                                   local_vectors_sha256=sha(vector_file)))
        for method in ('HimNet','HMG-MRL'):
            arm='A1-'+method;dest=folder/method;dest.mkdir(exist_ok=True)
            packed=packed_vectors(caches,arm,{idx:v for (idx,m),v in vectors.items() if m==method},args.device)
            for head_seed in (0,1,2):
                if any(r['stage']=='context' and r['split_name']==split and r['encoder_seed']==seed and
                       r['method']==method and r['head_seed']==head_seed for r in results):continue
                row=fit_readout(packed,arm,seed,head_seed,args,dest,cache_path)
                results.append(dict(row,stage='context',method=method,draw=-1,split_name=split,
                                    artifact_dir=str(dest),reference_artifact_dir=enc['artifact_dir'],
                                    local_vectors_sha256=sha(vector_file)))
                save_json(progress,results)
                print(f'STAGE context COMPLETE {len(results)}/240 readouts',flush=True)
            del packed
        del vectors,caches
        if args.device.startswith('cuda'):torch.cuda.empty_cache()
    assert len(results)==240 and sum(r['stage']=='context' for r in results)==60
    save_json(out/'complete.json',results)
    print('COMPLETE all 180 null-membership + 60 local-context readouts; no Encoder trained',flush=True)


if __name__=='__main__':main()
