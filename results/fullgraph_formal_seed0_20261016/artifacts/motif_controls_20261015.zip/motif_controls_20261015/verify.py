"""Verify serialized controls, reference linkage and all readout artifacts."""
import json
from pathlib import Path
import sys
from collections import Counter
import numpy as np
import torch
from audit_controls import HERE,SOURCE,mask_of,popcount,connected,sha

BASE=HERE.parent/'gine_motif_readout_20261014'
VALID=HERE.parent/'gine_motif_validation_20261014/results'


def main():
    out=HERE/'results'
    mf=json.loads((out/'manifest.json').read_text(encoding='utf-8'))
    cm=json.loads((HERE/'controls/manifest.json').read_text(encoding='utf-8'))
    assert sha(HERE/'run_stages.py')==mf['runner_sha256']
    assert sha(HERE/'PROTOCOL.md')==mf['protocol_sha256']
    assert sha(BASE/'run.py')==mf['core_sha256']
    assert sha(SOURCE)==mf['structure_sha256']==cm['source_sha256']
    assert sha(HERE/'controls/groups.json')==mf['controls_sha256']==cm['groups_sha256']
    assert sha(VALID/'complete.json')==mf['reference_sha256']
    records=json.loads(SOURCE.read_text(encoding='utf-8'))
    original={};neighbors={}
    for r in records:
        idx=r['source_row'];groups=[g['atoms'] for g in r['motifs']]+[[a] for a in r['uncovered_atoms']]
        original[(idx,r['method'])]=[mask_of(g) for g in groups]
        if idx not in neighbors:
            ns=[0]*len(r['atoms'])
            for b in r['bonds']:
                a,c=b['begin'],b['end'];ns[a]|=1<<c;ns[c]|=1<<a
            neighbors[idx]=ns
    controls=json.loads((HERE/'controls/groups.json').read_text(encoding='utf-8'))
    assert len(controls)==25200
    for c in controls:
        idx=c['source_row'];a=original[(idx,c['method'])];b=[mask_of(g) for g in c['groups']]
        assert len(a)==len(b) and [popcount(g) for g in a]==[popcount(g) for g in b]
        assert all(connected(g,neighbors[idx]) for g in b)
        assert all(popcount(x&y)==popcount(z&w) for i,(x,z) in enumerate(zip(a,b)) for y,w in zip(a[i+1:],b[i+1:]))
        assert [sum(bool(g&(1<<i)) for g in b) for i in range(len(neighbors[idx]))]==c['coverage']
        assert bool(set(a)!=set(b))==c['family_changed']
        if not c['family_changed']:assert a==b
    print('Verified 25200 structural control families',flush=True)
    rows=json.loads((out/'complete.json').read_text(encoding='utf-8'))
    assert len(rows)==240 and Counter(r['stage'] for r in rows)=={'null':180,'context':60}
    assert len({(r['stage'],r['split_name'],r['encoder_seed'],r['method'],r['draw'],r['head_seed']) for r in rows})==240
    refs=json.loads((VALID/'complete.json').read_text(encoding='utf-8'))
    refs={(r['split_name'],r['encoder_seed'],r['head_seed'],r['arm']):r for r in refs}
    caches={}
    for enc in mf['encoder_references']:
        folder=Path(enc['artifact_dir']);cp=folder/'encoder_best.pt';cachefile=folder/'atom_cache.pt'
        assert sha(cp)==enc['checkpoint_sha256'] and sha(cachefile)==enc['atom_cache_sha256']
        caches[(enc['split_name'],enc['seed'])]=torch.load(cachefile,map_location='cpu',weights_only=True)['splits']
        ctx=out/'context'/enc['split_name']/f"encoder{enc['seed']}"
        localmeta=json.loads((ctx/'cache_manifest.json').read_text(encoding='utf-8'))
        assert localmeta['encoder_sha256']==sha(cp) and localmeta['full_cache_sha256']==sha(cachefile)
        assert localmeta['local_vectors_sha256']==sha(ctx/'local_vectors.pt')
        diag=json.loads((ctx/'context_diagnostics.json').read_text(encoding='utf-8'))
        assert len(diag)==sum(len(r['motifs']) for r in records)
        assert all(np.isfinite(r['relative_l2']) and np.isfinite(r['cosine']) for r in diag)
    for i,r in enumerate(rows):
        ref=refs[(r['split_name'],r['encoder_seed'],r['head_seed'],r['arm'])]
        assert r['atom_cache_sha256']==ref['atom_cache_sha256'] and r['reference_artifact_dir']==ref['artifact_dir']
        assert r['train_phi_rows']==ref['train_phi_rows'] and r['train_padded_rows']==ref['train_padded_rows']
        path=Path(r['artifact_dir']);name=f"{r['arm']}_head{r['head_seed']}"
        model=torch.load(path/(name+'.pt'),map_location='cpu',weights_only=True)
        assert all(r[k]==v for k,v in model['metadata'].items())
        assert sum(v.numel() for v in model['state_dict'].values())==49665
        assert abs(min(h['valid_rmse'] for h in model['history'])-r['valid_rmse'])<1e-6
        cache=caches[(r['split_name'],r['encoder_seed'])]
        with np.load(path/(name+'_predictions.npz')) as pred:
            for split in ('valid','test'):
                assert np.array_equal(pred[split+'_ids'],cache[split]['ids'])
                rmse=float(np.sqrt(np.mean((pred[split]-cache[split]['y'].numpy())**2)))
                assert abs(rmse-r[split+'_rmse'])<1e-6
        if (i+1)%30==0:print(f'Verified {i+1}/240 readouts',flush=True)
    proof=dict(structural_control_families=25200,exact_size_coverage_overlap_connectivity=True,
               unchanged_control_order_preserved=True,encoder_weights_and_full_caches_unchanged=True,
               readout_runs=240,null_runs=180,local_context_runs=60,
               matched_parameter_count=49665,all_readouts_validation_best=True,
               saved_prediction_RMSE_and_row_IDs_verified=True,local_vector_cache_provenance_verified=True,
               source_hashes_verified=True,minimum_effect_threshold=None)
    (out/'verification.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
