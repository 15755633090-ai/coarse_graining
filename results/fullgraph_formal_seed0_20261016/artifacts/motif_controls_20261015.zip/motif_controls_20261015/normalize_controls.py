"""Keep bitwise-identical group order for unchanged families; no label access."""
import json
from pathlib import Path
from audit_controls import HERE,SOURCE,sha

out=HERE/'controls'
records=json.loads(SOURCE.read_text(encoding='utf-8'))
original={(r['source_row'],r['method']):[g['atoms'] for g in r['motifs']]+[[a] for a in r['uncovered_atoms']] for r in records}
path=out/'groups.json'
controls=json.loads(path.read_text(encoding='utf-8'))
for c in controls:
    if not c['family_changed']:
        c['groups']=original[(c['source_row'],c['method'])]
path.write_text(json.dumps(controls,ensure_ascii=False,indent=2),encoding='utf-8')
manifest=json.loads((out/'manifest.json').read_text(encoding='utf-8'))
manifest.update(groups_sha256=sha(path),unchanged_families_original_order=True,
                normalization_script_sha256=sha(Path(__file__)))
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('Normalized unchanged families to original group order; all chemical/null rules unchanged')
