"""Check isolation of cross-boundary messages without training an Encoder."""
from pathlib import Path
import torch
from torch_geometric.data import Batch
from run_stages import local_graphs,make_local_vectors,HERE
from run import graph,Baseline,seed_all

seed_all(12)
graphs={0:graph('CC(=O)O',0,0.),1:graph('CC',1,0.),2:graph('O.O',2,0.),3:graph('CCO',3,0.)}
records=[dict(source_row=0,method='HimNet',original_coverage_counts=[0,1,1,1],
              motifs=[dict(atoms=[1,2,3],boundary_bonds=[0])],uncovered_atoms=[0]),
         dict(source_row=1,method='HimNet',original_coverage_counts=[1,1],
              motifs=[dict(atoms=[0,1],boundary_bonds=[])],uncovered_atoms=[]),
         dict(source_row=2,method='HimNet',original_coverage_counts=[1,0],
              motifs=[dict(atoms=[0],boundary_bonds=[])],uncovered_atoms=[1]),
         dict(source_row=3,method='HMG-MRL',original_coverage_counts=[1,2,1],
              motifs=[dict(atoms=[0,1],boundary_bonds=[1]),dict(atoms=[1,2],boundary_bonds=[0])],uncovered_atoms=[])]
model=Baseline().eval().requires_grad_(False)
with torch.no_grad():
    batch=Batch.from_data_list(list(graphs.values()));h=model.encoder(batch)
    states=[h[batch.ptr[i]:batch.ptr[i+1]].cpu() for i in range(4)]
cache={'train':dict(atoms=states,ids=[0,1,2,3],y=torch.zeros(4))}
items,meta=local_graphs(graphs,records)
assert items[0].edge_index.shape[1]==4
assert torch.equal(items[0].x,graphs[0].x[[1,2,3]])
vectors=make_local_vectors(model.encoder,items,meta,records,cache,'cpu',HERE/'smoke_context')
torch.testing.assert_close(vectors[(1,'HimNet')][0],states[1].sum(0))
torch.testing.assert_close(vectors[(0,'HimNet')][-1],states[0][0],rtol=0,atol=0)
torch.testing.assert_close(vectors[(2,'HimNet')][-1],states[2][1],rtol=0,atol=0)
assert not torch.allclose(vectors[(0,'HimNet')][0],states[0][[1,2,3]].sum(0))
print('PASS: induced edges, unchanged original atom features, full-component equivalence, bondless groups, uncovered fallback, boundary sensitivity, frozen weights')
