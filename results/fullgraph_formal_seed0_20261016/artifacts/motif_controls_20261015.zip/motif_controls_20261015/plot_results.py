"""Isolated plotting process, avoiding mixing Torch and plotting OpenMP runtimes."""
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator,FormatStrFormatter

out=Path(__file__).resolve().parent/'results'
rows=json.loads((out/'intervals.json').read_text(encoding='utf-8'))
fig,axes=plt.subplots(1,2,figsize=(12,4.8))
for axis,stage,title,label in zip(axes,('null','context'),
        ('Chemical vs constrained membership perturbations','Removing cross-Motif messages'),
        ('Chemical - null RMSE (negative favors chemical)',
         'Local - Full RMSE (positive favors external messages)')):
    block=[r for r in rows if r['stage']==stage]
    axis.axvline(0,color='#333',lw=1)
    names=[]
    for i,r in enumerate(block):
        s=r['test'];color='#2563eb' if r['method']=='HimNet' else '#d97706'
        axis.errorbar(s['mean'],i,xerr=[[s['mean']-s['lower']],[s['upper']-s['mean']]],
                      fmt='o',capsize=4,color=color)
        names.append(r['split_name']+' / '+r['method'])
    axis.set_yticks(range(4),names);axis.invert_yaxis()
    axis.set_title(title,fontsize=10);axis.set_xlabel(label,fontsize=9);axis.grid(axis='x',alpha=.2)
    axis.xaxis.set_major_locator(MaxNLocator(nbins=4))
    axis.xaxis.set_major_formatter(FormatStrFormatter('%.3f' if stage=='null' else '%.2f'))
fig.suptitle('Frozen GINE; pointwise 95% t intervals over 5 encoder means per split',fontsize=11)
fig.tight_layout();fig.savefig(out/'intervals.png',dpi=180);plt.close(fig)
print(out/'intervals.png')
