"""Train/valid-only dynamic acceptance; never evaluates test rows."""
import argparse
import copy
from pathlib import Path
import torch
from .data import load_dataset, save_json, sha
from .paper_data import load_paper, prepare_him_graphs, HierarchicalBatch, load_hmg_features, hmg_inputs, source_inventory
from .scale_ablation import atom_graph, hmg_atom_model, copy_shared


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--paper', choices=['HimNet','HMG-MRL'], required=True)
    p.add_argument('--paper-root', type=Path, required=True)
    p.add_argument('--feature-cache', type=Path)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args(); a.output.mkdir(parents=True, exist_ok=False)
    torch.set_num_threads(4); torch.manual_seed(0)
    data_path=Path('motif/data/lipo.pt'); data=load_dataset(data_path)
    splits={s:[m for m in data['molecules'] if m['split']==s] for s in ('train','valid')}
    assert not set(m['row'] for m in splits['train']) & set(m['row'] for m in splits['valid'])
    rows={s:rs[:4] for s,rs in splits.items()}
    device='cuda:0'; cls,loader,cfg=load_paper(a.paper_root,a.paper,device)
    provenance=source_inventory(a.paper_root)
    input_probes=[]
    if a.paper=='HimNet':
        allrows=rows['train']+rows['valid']
        fullgraphs=prepare_him_graphs(allrows,loader)
        atomgraphs={r['row']:atom_graph(r,loader) for r in allrows}
        g=fullgraphs[allrows[0]['row']]
        full=cls('memory',len(g['f_atoms'][0]),len(g['f_bonds'][0]),g['fp_x'].shape[-1],device=device,out_dim=1).to(device)
        atom=copy.deepcopy(full)
        for r in allrows:
            f,b=fullgraphs[r['row']],atomgraphs[r['row']]; n=int(b['num_part'][0][0])
            assert f['f_atoms'][:n]==b['f_atoms'][:n]
            assert f['f_atoms'][-1]==b['f_atoms'][-1]
            assert torch.equal(f['fp_x'],b['fp_x'])
        def forward(model, rs, arm, training):
            graphs=fullgraphs if arm=='full' else atomgraphs
            batch=HierarchicalBatch([graphs[r['row']] for r in rs])
            if training:
                batch.f_atoms.requires_grad_(True)
                motif_indices=[j for (start,size),r in zip(batch.a_scope,rs)
                               for j in range(start+int(graphs[r['row']]['num_part'][0][0]),start+size-1)]
                input_probes.append((arm,batch.f_atoms,motif_indices))
            ligand=model.encoder(batch)
            if training:
                fp,proj,views=model.fp_encoder(batch.fp_x.to(device).float(),training=True)
                model.contrastive_data={'graph_proj':torch.nn.functional.normalize(model.graph_proj_head(ligand),dim=1),'fp_proj':proj,'fp_view_projs':views}
                aux=model.compute_contrastive_loss()
            else:
                fp=model.fp_encoder(batch.fp_x.to(device).float()); aux=ligand.sum()*0
            pred=model.mlp(model.feature_fusion(torch.stack([ligand,fp])))
            return pred.flatten(),aux
        weight=.2
    else:
        features,assemble=load_hmg_features(a.feature_cache,a.paper_root)
        inputs={s:hmg_inputs(rs,features,assemble,device)[0] for s,rs in rows.items()}
        x=inputs['train']; full=cls(x['x_atoms'].shape[-1],x['x_bonds'].shape[-1],1).to(device)
        atom=hmg_atom_model(full,a.output/'atom_forward.py')
        def forward(model, rs, arm, training):
            phase='train' if rs is rows['train'] else 'valid'
            kw=dict(inputs[phase])
            if training and arm=='full':
                kw['frag_src_features']=kw['frag_src_features'].detach().clone().requires_grad_(True)
                input_probes.append((arm,kw['frag_src_features'],None))
            if arm=='atom':
                del kw['frag_src_features']; del kw['frag_src_valid_mask']
                pred,aux=model(**kw)
            else:
                out=model(**kw); pred,aux=out[1],out[2]
            return pred.flatten(),aux
        weight=cfg.ct_loss_coff
    mapping=copy_shared(full,atom); save_json(a.output/'initialization.json',mapping)
    y=torch.tensor([r['label'] for r in splits['train']],device=device)
    mean,std=y.mean(),y.std(unbiased=False).clamp_min(1e-6)
    report={'paper':a.paper,'test_evaluated':False,'test_rows_used':False,'smoke':True,'formal_training_started':False,
            'rows':{s:[r['row'] for r in rs] for s,rs in rows.items()},'data_sha256':sha(data_path),
            'source':provenance,'arms':{}}
    if a.feature_cache: report['feature_cache_sha256']=sha(a.feature_cache)
    for arm,model in [('full',full),('atom',atom)]:
        optimizer=torch.optim.AdamW(model.parameters(),lr=1e-4,weight_decay=1e-5)
        model.train(); pred,aux=forward(model,rows['train'],arm,True)
        target=torch.tensor([r['label'] for r in rows['train']],device=device)
        mse=(pred-(target-mean)/std).square().mean()
        gradient_sources={}
        for name,loss in [('mse',mse),('aux',aux)]:
            grads=torch.autograd.grad(loss,tuple(model.parameters()),retain_graph=True,allow_unused=True) if all(p.requires_grad for p in model.parameters()) else None
            # Fixed zero parameters in HimNet are excluded explicitly.
            if grads is None:
                ps=[(n,p) for n,p in model.named_parameters() if p.requires_grad]
                gs=torch.autograd.grad(loss,[p for _,p in ps],retain_graph=True,allow_unused=True)
            else: ps=list(model.named_parameters()); gs=grads
            assert all(g is None or torch.isfinite(g).all() for g in gs)
            gradient_sources[name]=[n for (n,_),g in zip(ps,gs) if g is not None and g.abs().sum()>0]
        loss=mse+weight*aux; assert torch.isfinite(loss)
        optimizer.zero_grad(); loss.backward()
        probe_reports=[]
        for probe_arm,tensor,indices in input_probes:
            if probe_arm!=arm: continue
            if indices is None:
                # Exclude whole-molecule token and padding from motif evidence.
                mask=inputs['train']['frag_src_valid_mask'][:,1:]>0
                motif_grad=tensor.grad[:,1:][mask]
            elif indices:
                motif_grad=tensor.grad[indices]
            else:
                assert arm=='atom'; probe_reports.append({'motif_nodes':0}); continue
            assert torch.isfinite(motif_grad).all() and motif_grad.abs().sum()>0
            probe_reports.append({'motif_gradient_abs_sum':motif_grad.abs().sum().item()})
        grad={n:('none' if p.grad is None else 'nonzero' if p.grad.abs().sum()>0 else 'zero') for n,p in model.named_parameters()}
        before={n:p.detach().clone() for n,p in model.named_parameters()}
        torch.nn.utils.clip_grad_norm_(model.parameters(),5,error_if_nonfinite=True); optimizer.step()
        updated=[n for n,p in model.named_parameters() if not torch.equal(before[n],p)]
        model.eval()
        with torch.no_grad(): val,_=forward(model,rows['valid'],arm,False)
        assert torch.isfinite(val).all()
        valid_target=torch.tensor([r['label'] for r in rows['valid']],device=device)
        rmse=((val*std+mean-valid_target).square().mean().sqrt()).item()
        torch.save({'model':model.state_dict(),'valid_rmse':rmse,'epoch':1,'mean':mean,'std':std},a.output/f'{arm}_best.pt')
        # Perturb weights to make reload check non-vacuous.
        with torch.no_grad(): next(model.parameters()).add_(1)
        model.load_state_dict(torch.load(a.output/f'{arm}_best.pt',weights_only=True)['model'],strict=True)
        with torch.no_grad(): again,_=forward(model,rows['valid'],arm,False)
        assert torch.equal(val,again)
        report['arms'][arm]={'loss':loss.item(),'valid_rmse':rmse,'gradients':grad,'gradient_sources':gradient_sources,'updated':updated,
            'motif_input_probes':probe_reports,
            'parameters':sum(p.numel() for p in model.parameters()),'trainable':sum(p.numel() for p in model.parameters() if p.requires_grad),
            'active':sum(p.numel() for n,p in model.named_parameters() if grad[n]=='nonzero'),'reload_exact':True}
    assert source_inventory(a.paper_root)==provenance
    if a.paper=='HMG-MRL':
        assert any(n.startswith('motif_encoder.') for n in report['arms']['full']['gradient_sources']['mse'])
        assert not any('frag_' in n or 'motif_encoder' in n or 'projector_' in n for n in atom.state_dict())
    report['implementation_sha256']={name:sha(Path(__file__).parent/name) for name in ('scale_ablation.py','check_scale_ablation.py')}
    report['passed']=True; save_json(a.output/'acceptance.json',report)
    print({'paper':a.paper,'passed':True,'test_accessed':False},flush=True)


if __name__=='__main__': main()
