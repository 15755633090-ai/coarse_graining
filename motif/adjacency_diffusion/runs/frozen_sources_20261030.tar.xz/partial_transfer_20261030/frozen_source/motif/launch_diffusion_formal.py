"""Frozen serial pipeline: acceptance, one pretraining seed, both paper controls."""
import argparse,json,shutil,subprocess,sys,time
from pathlib import Path
from .data import save_json,sha


def worker(run,root):
    import torch
    from .paper_data import load_paper,prepare_him_graphs,source_inventory
    from .data import load_dataset
    from .him_repair_20261019.graphs import repair_graph,SCHEMA
    source=run/'source';papers=run/'upstream';data=root/'motif/data/lipo.pt'
    done=[]
    def execute(name,module,opts):
        cmd=[sys.executable,'-X','utf8','-u','-m',module,*map(str,opts)]
        with (run/f'{name}.stdout.log').open('w',encoding='utf-8') as out,(run/f'{name}.stderr.log').open('w',encoding='utf-8') as err:
            proc=subprocess.Popen(cmd,cwd=source,stdout=out,stderr=err,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            save_json(run/f'{name}.process.json',{'pid':proc.pid,'command':cmd})
            save_json(run/'status.json',{'phase':'running','stage':name,'pid':proc.pid,'completed_stages':done,'updated':time.time()})
            code=proc.wait()
        save_json(run/f'{name}.exit.json',{'exit_code':code})
        if code:raise RuntimeError(f'{name} failed; pipeline stopped')
        done.append(name)
    try:
        execute('module_checks','motif.check_fixed',[])
        ds=load_dataset(data);_,loader,_=load_paper(papers/'him','HimNet','cpu')
        rows=[r for s in ('train','valid') for r in [x for x in ds['molecules'] if x['split']==s][:2]]
        graphs=prepare_him_graphs(rows,loader)
        graphs={k:repair_graph(v) for k,v in graphs.items()}
        torch.save({'graphs':graphs,'repair_schema':SCHEMA,'data_sha256':sha(data),
                    'paper_source_sha256':source_inventory(papers/'him')},run/'smoke_graphs.pt')
        pre=['--data',data,'--seed',0,'--hidden',128,'--layers',3,'--steps',100,'--min-noise',.05,'--max-noise',.85,
             '--region-probability',.2,'--region-fraction',.2,'--batch-size',16,'--lr',.0002]
        execute('pretrain_smoke','motif.pretrain_fixed',pre+['--output',run/'pretrain_smoke','--epochs',1,'--smoke-per-split',32])
        features=root/'motif/runs/hmg_features_finite_20261016/features.pickle'
        def downstream(paper,prefix,smoke):
            opts=['--paper',paper,'--paper-root',papers/prefix,'--data',data,'--checkpoint',run/('pretrain_smoke' if smoke else 'pretrain')/'best.pt',
                  '--output',run/(prefix+('_smoke' if smoke else '_formal')),'--epochs',1 if smoke else 100,'--patience',20,
                  '--batch-size',2 if smoke else 16,'--lr',.0001,'--encoder-lr',.00001,'--seeds',*([0] if smoke else [0,1,2])]
            if prefix=='him':opts+=['--him-repair','--him-graph-cache',run/'smoke_graphs.pt' if smoke else root/'motif/runs/him_repaired_preflight_20261019/him_graphs.pt']
            else:opts+=['--hmg-feature-cache',features]
            if smoke:opts+=['--smoke-per-split',2]
            execute(prefix+('_smoke' if smoke else '_formal'),'motif.launch_fixed',opts)
            if smoke:
                for arm in ('original','random','pretrained'):
                    r=json.loads((run/(prefix+'_smoke')/'seed_0'/arm/'results.json').read_text(encoding='utf-8'))
                    assert r['smoke'] and r['test_rmse'] is None and not r['test_evaluated_after_selection']
        downstream('HimNet','him',True);downstream('HMG-MRL','hmg',True)
        save_json(run/'acceptance.json',{'passed':True,'both_three_arm_smokes':True,'smoke_test_evaluated':False,
                  'him_repaired_common_graph':True,'random_encoder_does_not_load_weights':True})
        execute('pretrain_formal','motif.pretrain_fixed',pre+['--output',run/'pretrain','--epochs',50])
        downstream('HimNet','him',False);downstream('HMG-MRL','hmg',False)
        import numpy as np
        from scipy.stats import t
        summary={}
        for paper,prefix in [('HimNet repaired','him'),('HMG-MRL','hmg')]:
            values={arm:[] for arm in ('original','random','pretrained')}
            for seed in (0,1,2):
                for arm in values:
                    r=json.loads((run/(prefix+'_formal')/f'seed_{seed}'/arm/'results.json').read_text(encoding='utf-8'))
                    assert not r['smoke'];values[arm].append(r['test_rmse'])
            stats={}
            for first,second in [('pretrained','original'),('random','original'),('pretrained','random')]:
                d=np.array(values[first])-values[second];m=float(d.mean());s=float(d.std(ddof=1));h=float(t.ppf(.975,2)*s/np.sqrt(3))
                stats[first+'_minus_'+second]={'paired_delta':d.tolist(),'mean':m,'sd':s,'paired_t_95_ci':[m-h,m+h]}
            summary[paper]={'rmse':values,'comparisons':stats}
        save_json(run/'comparison.json',summary);save_json(run/'status.json',{'phase':'complete','completed_stages':done})
    except Exception as exc:
        save_json(run/'status.json',{'phase':'failed','error':str(exc),'completed_stages':done});raise


def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--root',type=Path,required=True)
    p.add_argument('--worker',action='store_true');a=p.parse_args();run=a.output.resolve();root=a.root.resolve()
    if a.worker:worker(run,root);return
    run.mkdir(parents=True,exist_ok=False);(run/'source/motif').mkdir(parents=True)
    for f in (root/'motif').glob('*.py'):shutil.copy2(f,run/'source/motif'/f.name)
    shutil.copytree(root/'motif/him_repair_20261019',run/'source/motif/him_repair_20261019',ignore=shutil.ignore_patterns('__pycache__','*.log'))
    for prefix,base in [('him',root/'motif/runs/scale_pairs_3seeds_20261018/upstream/him'),('hmg',root/'research_code_audit/HMG-MRL')]:
        for f in base.rglob('*.py'):
            dst=run/'upstream'/prefix/f.relative_to(base);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,dst)
    save_json(run/'protocol.json',{'objective':'fixed-topology attribute denoising, no motif condition; residual motif injection',
              'pretrain':{'seed':0,'epochs':50,'hidden':128,'layers':3,'steps':100,'min_noise':.05,'max_noise':.85,'lr':.0002},
              'downstream':{'papers':['HimNet repaired','HMG-MRL'],'seeds':[0,1,2],'arms':['original','random','pretrained'],
                  'epochs':100,'patience':20,'batch_size':16,'lr':.0001,'encoder_lr':.00001,'aux_weight':0,'gate_init':.1},
              'formal_downstream_models':18,'same_backbone_initialization_checked':True,
              'random_control':'same architecture and optimizer; no pretrained weights loaded; not independently optimized',
              'limits':'one pretraining seed; one fixed split; historical test seen; n=3 intervals unstable',
              'stages':'module checks, small pretrain, both train/valid-only smokes, formal pretrain, serial downstream',
              'new_baselines_required':'all arms auxiliary zero; cannot reuse historical auxiliary-positive Full scores'})
    save_json(run/'source_manifest.json',{str(f.relative_to(run)):sha(f) for folder in ('source','upstream') for f in (run/folder).rglob('*.py')})
    save_json(run/'status.json',{'phase':'prepared'});print(str(run),flush=True)


if __name__=='__main__':main()
