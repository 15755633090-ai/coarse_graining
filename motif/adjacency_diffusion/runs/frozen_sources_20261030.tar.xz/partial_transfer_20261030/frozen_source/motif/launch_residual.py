"""Fixed three-seed downstream comparison, with shared seed-0 pretraining."""
import argparse
import json
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def save(path,obj):path.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')

def worker(run,root,resume=False,fast_fullgraph=False):
    import torch
    previous=root/'motif/runs/fullgraph_formal_seed0_20261016'
    existing={}
    if resume:
        for item in json.loads((run/'completed_results.json').read_text(encoding='utf-8')):
            existing[(item['seed'],item['paper'],item['fusion'])]=item
    def execute(name,args):
        cmd=[sys.executable,'-X','utf8','-u','-m','motif.train_paper',*map(str,args)]
        with (run/(name+'.stdout.log')).open('w',encoding='utf-8') as out,(run/(name+'.stderr.log')).open('w',encoding='utf-8') as err:
            proc=subprocess.Popen(cmd,cwd=Path(__file__).resolve().parents[1],stdout=out,stderr=err,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            save(run/(name+'.process.json'),{'pid':proc.pid,'command':cmd})
            save(run/'status.json',{'phase':'running','stage':name,'pid':proc.pid,'updated':time.time()})
            code=proc.wait()
        save(run/(name+'.exit.json'),{'exit_code':code})
        if code:raise RuntimeError(f'{name} failed; see stderr log')
    def arguments(paper,prefix,seed,arm,output,smoke=False):
        args=['--paper',paper,'--paper-root',root/('research_code_audit/HMG-MRL' if prefix=='hmg' else 'coarse_graining1/HimNet_reproduction_20261013/windows'),
              '--data',root/'motif/data/lipo.pt','--output',output,'--seed',seed,'--epochs',1 if smoke else 100,
              '--patience',20,'--batch-size',2 if smoke else 16,'--motif-batch-size',4,'--pair-budget',262144,'--lr',.0001,
              '--arm','original' if arm=='original' else 'pretrained']
        if arm!='original':args+=['--fullgraph','--checkpoint',previous/(prefix+'_pretrain/best.pt'),'--fusion','residual' if arm=='residual' else 'replace','--gate-init',.1]
        if arm!='original' and fast_fullgraph:args+=['--fast-fullgraph']
        if prefix=='hmg':args+=['--hmg-feature-cache',root/'motif/runs/hmg_features_finite_20261016/features.pickle']
        else:args+=['--him-graph-cache',previous/'him_original/him_graphs.pt']
        if smoke:args+=['--smoke-per-split',2]
        return args
    all_results=[]
    try:
        # Real original models, full pretrained dimensions and six real molecules.
        for paper,prefix in [('HimNet','him'),('HMG-MRL','hmg')]:
            name=prefix+'_residual_smoke';output=run/name
            if not resume:
                execute(name,arguments(paper,prefix,0,'residual',output,True))
            elif not (output/'results.json').exists():
                raise ValueError('Missing completed real-model check')
            state=torch.load(output/'best.pt',map_location='cpu',weights_only=True)['model']
            gates=[v for k,v in state.items() if k.endswith('motif_gate')]
            assert gates and all(torch.isfinite(v).all() for v in gates)
            assert any(not torch.equal(v.sigmoid(),torch.full_like(v,.1)) for v in gates)
        save(run/'smoke_checks.json',{'both_real_models_passed':True,'gate_parameters_updated':True,'strict_reload':True})
        for seed in (0,1,2):
            for paper,prefix in [('HimNet','him'),('HMG-MRL','hmg')]:
                initial=None
                for arm in ('original','replace','residual'):
                    saved=existing.get((seed,paper,arm))
                    if saved:
                        output=Path(saved['path']);reused=saved['reused']
                        if json.loads((output/'results.json').read_text(encoding='utf-8'))!=saved['result']:
                            raise ValueError('Completed result changed since pause')
                    elif seed==0 and arm!='residual':
                        output=previous/(prefix+('_original' if arm=='original' else '_pretrained'))
                        reused=True
                    else:
                        name=f'{prefix}_{arm}_seed{seed}';output=run/name
                        if output.exists():
                            attempt=1
                            while (run/(name+f'_restart{attempt}')).exists():attempt+=1
                            name+=f'_restart{attempt}';output=run/name
                        execute(name,arguments(paper,prefix,seed,arm,output));reused=False
                    result=json.loads((output/'results.json').read_text(encoding='utf-8'))
                    if result['smoke']:raise ValueError('Smoke result in formal comparison')
                    state=torch.load(output/'initial_backbone.pt',map_location='cpu',weights_only=True)
                    if initial is None:initial=state
                    elif state.keys()!=initial.keys() or not all(torch.equal(state[k],initial[k]) for k in initial):
                        raise ValueError('Unpaired original backbone initialization')
                    all_results.append({'seed':seed,'paper':paper,'fusion':arm,'reused':reused,'path':str(output),'result':result})
                    save(run/'completed_results.json',all_results)
        save(run/'comparison.json',{'runs':all_results,'backbones_paired':True,
            'pretraining':'fixed seed-0 checkpoint for every downstream seed','downstream_seeds':[0,1,2],
            'design_selection':'validation only; no adaptive hyperparameters or extra seeds'})
        save(run/'status.json',{'phase':'complete','updated':time.time()})
    except Exception as exc:
        save(run/'status.json',{'phase':'failed','error':str(exc),'updated':time.time()});raise

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--resume',action='store_true',help='Reuse completed groups; restart unfinished groups in new directories')
    p.add_argument('--fast-fullgraph',action='store_true')
    p.add_argument('--root',type=Path,default=ROOT);p.add_argument('--worker',action='store_true')
    args=p.parse_args();run=args.output.resolve();root=args.root.resolve()
    if args.worker:worker(run,root,args.resume,args.fast_fullgraph);return
    run.mkdir(parents=True,exist_ok=False);source=run/'source';(source/'motif').mkdir(parents=True)
    for f in (root/'motif').glob('*.py'):shutil.copy2(f,source/'motif'/f.name)
    shutil.copytree(root/'扩散GNN/01_扩散预训练/bond_diffusion',source/'扩散GNN/01_扩散预训练/bond_diffusion',ignore=shutil.ignore_patterns('__pycache__'))
    save(run/'protocol.json',{'downstream_seeds':[0,1,2],'arms':['original','replace','residual'],
        'gate':'learned channel sigmoid shared across motifs; initial 0.1','joint_finetuning':True,
        'fixed_pretraining_seed':0,'epochs':100,'patience':20,'lr':.0001,'batch_size':16,
        'seed0_original_replace_reused':True,'new_formal_runs':14,'real_model_smoke_checks':2,
        'design_selection':'validation only; fixed budget; do not choose hyperparameters using test'})
    print(json.dumps({'prepared':str(run),'worker_module':'motif.launch_residual'},ensure_ascii=False))

if __name__=='__main__':main()
