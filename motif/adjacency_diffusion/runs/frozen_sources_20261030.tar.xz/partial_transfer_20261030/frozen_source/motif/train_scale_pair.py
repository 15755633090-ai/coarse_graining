"""Paired Full/Atom-only training under a fixed supervised protocol."""
import argparse
import hashlib
import json
import random
import time
from pathlib import Path
import numpy as np
import torch
from .data import load_dataset, save_json, sha
from .paper_data import load_paper, prepare_him_graphs, load_hmg_features, hmg_inputs, source_inventory
from .scale_runtime import ScaleRuntime, validate_him, validate_hmg


def batches(rows,batch_size,seed=None):
    order=list(range(len(rows))) if seed is None else torch.randperm(len(rows),generator=torch.Generator().manual_seed(seed)).tolist()
    groups=[order[i:i+batch_size] for i in range(0,len(order),batch_size)]
    if len(groups)>1 and len(groups[-1])==1: groups[-2].extend(groups.pop())
    return [[rows[i] for i in g] for g in groups]


def seed_all(seed):
    random.seed(seed);np.random.seed(seed);torch.manual_seed(seed);torch.cuda.manual_seed_all(seed)


def identities(root):
    return {'upstream':source_inventory(root),'implementation':{p.name:sha(p) for p in Path(__file__).parent.glob('*.py')},
            'him_repair':{p.name:sha(p) for p in (Path(__file__).parent/'him_repair_20261019').glob('*.py')}}


def preflight(a,data,splits):
    rows=data['molecules']; cls,loader,cfg=load_paper(a.paper_root,a.paper,a.device)
    source=source_inventory(a.paper_root)
    if a.paper=='HimNet':
        graphs=prepare_him_graphs(rows,loader)
        from .scale_ablation import atom_graph
        for r in rows:
            f,g=graphs[r['row']],atom_graph(r,loader);validate_him(f);validate_him(g)
            n=Chem.MolFromSmiles(r['smiles']).GetNumAtoms()
            assert f['f_atoms'][:n]==g['f_atoms'][:n] and f['f_atoms'][-1]==g['f_atoms'][-1]
        torch.save({'graphs':graphs,'data_sha256':sha(a.data),'paper_source_sha256':source},a.output/'him_graphs.pt')
    else:
        features,assemble=load_hmg_features(a.feature_cache,a.paper_root)
        for i,rs in enumerate(batches(rows,16)):
            x,_,_=hmg_inputs(rs,features,assemble,'cpu');validate_hmg(x,rs)
            if i%25==0: print({'preflight_rows':min((i+1)*16,len(rows))},flush=True)
    assert source_inventory(a.paper_root)==source
    result={'passed':True,'paper':a.paper,'data_sha256':sha(a.data),'paper_source_sha256':source,
            'rows':{s:[r['row'] for r in rs] for s,rs in splits.items()},
            'index_validated_rows':len(rows),'test_forward':False,'test_labels_used_for_fit':False}
    if a.feature_cache:result['feature_cache_sha256']=sha(a.feature_cache)
    save_json(a.output/'preflight.json',result)


from rdkit import Chem


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--paper',choices=['HimNet','HMG-MRL'],required=True)
    p.add_argument('--paper-root',type=Path,required=True);p.add_argument('--feature-cache',type=Path)
    p.add_argument('--data',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--preflight',action='store_true');p.add_argument('--preflight-dir',type=Path)
    p.add_argument('--seed',type=int,default=0);p.add_argument('--epochs',type=int,default=100)
    p.add_argument('--patience',type=int,default=20);p.add_argument('--batch-size',type=int,default=16)
    p.add_argument('--lr',type=float,default=1e-4);p.add_argument('--device',default='cuda:0')
    p.add_argument('--smoke',action='store_true',help='32 train and 16 validation rows, no test forward')
    p.add_argument('--loss-ablation',action='store_true',help='Full prediction graph, targeted alignment removed')
    p.add_argument('--reference-pair',type=Path)
    p.add_argument('--him-repair',action='store_true')
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
    assert a.batch_size>=2 and a.epochs>=1 and a.patience>=1
    assert not a.him_repair or (a.paper=='HimNet' and not a.loss_ablation and not a.preflight)
    torch.set_num_threads(4);seed_all(a.seed)
    data=load_dataset(a.data);splits={s:[r for r in data['molecules'] if r['split']==s] for s in ('train','valid','test')}
    ids=[r['row'] for r in data['molecules']];assert len(ids)==len(set(ids))
    assert sum(map(len,splits.values()))==len(ids) and all(splits.values())
    assert all(np.isfinite(r['label']) for r in data['molecules'])
    if a.preflight: preflight(a,data,splits);return
    assert a.preflight_dir is not None
    pf=json.loads((a.preflight_dir/'preflight.json').read_text(encoding='utf-8'))
    assert pf['passed'] and pf['paper']==a.paper and pf['data_sha256']==sha(a.data)
    assert pf['paper_source_sha256']==source_inventory(a.paper_root)
    assert pf['rows']=={s:[r['row'] for r in rs] for s,rs in splits.items()}
    if a.feature_cache: assert pf['feature_cache_sha256']==sha(a.feature_cache)
    graph_cache=a.preflight_dir/'him_graphs.pt' if a.paper=='HimNet' else None
    if a.him_repair:
        from .him_repair_20261019.graphs import SCHEMA
        assert pf['repair_schema']==SCHEMA and pf['cache_sha256']==sha(graph_cache)
        assert pf['repair_source']==identities(a.paper_root)['him_repair']
    if graph_cache and not a.him_repair:
        cache=torch.load(graph_cache,map_location='cpu',weights_only=True)
        assert cache['data_sha256']==pf['data_sha256'] and cache['paper_source_sha256']==pf['paper_source_sha256']
        del cache
    source=identities(a.paper_root)
    y=torch.tensor([r['label'] for r in splits['train']]);mean=y.mean().item();std=y.std(unbiased=False).clamp_min(1e-6).item()
    selected={s:rs[:(32 if s=='train' else 16)] if a.smoke else rs for s,rs in splits.items() if not(a.smoke and s=='test')}
    rows=[r for rs in selected.values() for r in rs]
    runtime=ScaleRuntime(a.paper,a.paper_root,rows,a.output,a.seed,a.device,a.feature_cache,graph_cache,a.him_repair)
    runtime.loss_ablation=a.loss_ablation
    if a.loss_ablation:
        assert a.reference_pair is not None
        reference=torch.load(a.reference_pair/'initial_states.pt',map_location='cpu',weights_only=True)['full']
        actual=runtime.full.state_dict()
        assert reference.keys()==actual.keys() and all(torch.equal(reference[k],actual[k].cpu()) for k in actual)
        save_json(a.output/'reference_initialization.json',{'exact_equal':True,'reference':str(a.reference_pair),'tensors':len(actual)})
        del reference
    initial={arm:{k:v.detach().cpu().clone() for k,v in model.state_dict().items()}
             for arm,model in [('full',runtime.full),('atom',runtime.atom)]}
    torch.save(initial,a.output/'initial_states.pt')
    if a.smoke and a.loss_ablation:
        from .scale_runtime import him_alignment_parts
        model=runtime.full;model.train();group=selected['train'][:4]
        runtime.loss_ablation=False;seed_all(12345)
        before_pred,before_aux=runtime.forward(model,group,'full',True)
        if a.paper=='HimNet':
            graph_loss,view_loss=him_alignment_parts(model)
            assert torch.allclose(before_aux,graph_loss+view_loss,atol=1e-7)
        model.load_state_dict(initial['full'],strict=True)
        runtime.loss_ablation=True;seed_all(12345)
        after_pred,after_aux=runtime.forward(model,group,'full',True)
        assert torch.equal(before_pred,after_pred)
        target=torch.tensor([r['label'] for r in group],device=a.device)
        mse=(after_pred-(target-mean)/std).square().mean()
        names,params=zip(*[(n,p) for n,p in model.named_parameters() if p.requires_grad])
        grads=torch.autograd.grad(mse,params,retain_graph=True,allow_unused=True)
        active=[n for n,g in zip(names,grads) if g is not None and g.abs().sum()>0]
        assert all(g is None or torch.isfinite(g).all() for g in grads)
        if a.paper=='HMG-MRL':
            assert after_aux.item()==0 and any(n.startswith('motif_encoder.') for n in active)
        else:
            assert torch.allclose(after_aux,view_loss,atol=1e-7)
            gs=torch.autograd.grad(after_aux,params,allow_unused=True)
            assert all(g is None for n,g in zip(names,gs) if n.startswith('graph_proj_head.'))
            assert any(g is not None and g.abs().sum()>0 for n,g in zip(names,gs) if n.startswith('fp_encoder.'))
        save_json(a.output/'loss_graph_acceptance.json',{'passed':True,'same_training_prediction_exact':True,
                  'motif_prediction_path_preserved':True,'mse_active_parameters':active,
                  'original_aux':before_aux.item(),'ablated_aux':after_aux.item(),'test_evaluated':False})
        model.load_state_dict(initial['full'],strict=True)
    manifest={'paper':a.paper,'seed':a.seed,'smoke':a.smoke,'scope':'paper mechanisms under unified supervised protocol',
              'data_sha256':pf['data_sha256'],'rows':{s:[r['row'] for r in rs] for s,rs in selected.items()},
              'target_mean':mean,'target_std':std,'source':source,'preflight':pf,
              'args':{k:str(v) if isinstance(v,Path) else v for k,v in vars(a).items()},
              'aux_weight_full':runtime.weight,'aux_weight_atom':runtime.weight if a.paper=='HimNet' else 0,
              'parameters':{arm:sum(p.numel() for p in model.parameters()) for arm,model in [('full',runtime.full),('atom',runtime.atom)]},
              'test_policy':'one final test per arm after validation selection; no test in smoke',
              'historical_test_seen':True,'capacity_matched':a.paper=='HimNet'}
    manifest['loss_ablation']=a.loss_ablation
    save_json(a.output/'manifest.json',manifest)
    def evaluate(model,rs,arm):
        model.eval();pred=[]
        with torch.no_grad():
            for group in batches(rs,a.batch_size):
                out,_=runtime.forward(model,group,arm,False)
                assert torch.isfinite(out).all()
                pred.extend((out*std+mean).cpu().tolist())
        targets=[r['label'] for r in rs]
        score=float(np.sqrt(np.mean((np.asarray(pred)-targets)**2)))
        assert np.isfinite(score)
        return score,{'row_ids':[r['row'] for r in rs],'prediction':pred,'target':targets}
    results={}
    for arm,model in [('full',runtime.full),('atom',runtime.atom)]:
        if a.loss_ablation and arm=='atom':continue
        optimizer=torch.optim.AdamW([p for p in model.parameters() if p.requires_grad],lr=a.lr,weight_decay=1e-5)
        best=float('inf');best_epoch=0;history=[]
        for epoch in range(1,a.epochs+1):
            seed_all(a.seed+4000+epoch);model.train();started=time.perf_counter();losses=[]
            for i,group in enumerate(batches(selected['train'],a.batch_size,a.seed+epoch)):
                pred,aux=runtime.forward(model,group,arm,True)
                target=torch.tensor([r['label'] for r in group],device=a.device)
                loss=(pred-(target-mean)/std).square().mean()+runtime.weight*aux
                if not torch.isfinite(loss):raise FloatingPointError(f'{arm} epoch {epoch} batch {i} rows {[r["row"] for r in group]}')
                optimizer.zero_grad(set_to_none=True);loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(),5,error_if_nonfinite=True);optimizer.step();losses.append(loss.item())
                if i%25==0:save_json(a.output/'progress.json',{'arm':arm,'epoch':epoch,'batch':i,'phase':'train'})
            valid,_=evaluate(model,selected['valid'],arm)
            history.append({'epoch':epoch,'valid_rmse':valid,'mean_batch_objective':float(np.mean(losses)),'seconds':time.perf_counter()-started})
            if valid<best:
                best=valid;best_epoch=epoch
                torch.save({'model':{k:v.detach().cpu().clone() for k,v in model.state_dict().items()},'epoch':epoch,
                            'valid_rmse':valid,'mean':mean,'std':std},a.output/f'{arm}_best.pt')
            save_json(a.output/f'{arm}_history.json',history)
            save_json(a.output/'progress.json',{'arm':arm,**history[-1],'phase':'epoch_complete'})
            print({'arm':arm,**history[-1]},flush=True)
            if epoch-best_epoch>=a.patience:break
        assert best_epoch>0
        assert min(history,key=lambda r:r['valid_rmse'])['epoch']==best_epoch
        model.load_state_dict(torch.load(a.output/f'{arm}_best.pt',weights_only=True)['model'],strict=True)
        valid,pred=evaluate(model,selected['valid'],arm);assert abs(valid-best)<1e-7
        save_json(a.output/f'{arm}_valid_predictions.json',pred)
        before=np.asarray(pred['prediction'])
        with torch.no_grad():next(model.parameters()).add_(1)
        model.load_state_dict(torch.load(a.output/f'{arm}_best.pt',weights_only=True)['model'],strict=True)
        _,again=evaluate(model,selected['valid'],arm);assert np.array_equal(before,again['prediction'])
        result={'valid_rmse':best,'best_epoch':best_epoch,'epochs_run':len(history),'reload_exact':True,'test_evaluated':False}
        if not a.smoke:
            score,pred=evaluate(model,selected['test'],arm);save_json(a.output/f'{arm}_test_predictions.json',pred)
            result.update(test_rmse=score,test_evaluated=True)
        results[arm]=result;save_json(a.output/'results_partial.json',results)
    assert identities(a.paper_root)==source
    result={'paper':a.paper,'seed':a.seed,'smoke':a.smoke,'arms':results,'shared_initialization_exact':True,
            'test_evaluated':not a.smoke,'source_unchanged':True}
    if not a.smoke and not a.loss_ablation:result['delta_rmse']=results['full']['test_rmse']-results['atom']['test_rmse']
    save_json(a.output/'results.json',result)


if __name__=='__main__':main()
