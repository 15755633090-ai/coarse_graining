"""Train paired prediction heads on one immutable three-view feature cache."""
import csv
import statistics
import time

import torch

from .data import save_json
from .him_scale_readout import matched_width


def table(path, rows):
    with path.open('w', newline='', encoding='utf-8-sig') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)


def configurations(hidden, width, arms, builder):
    configs = [dict(name=arm, arm=arm, width=width, control='main') for arm in arms]
    matches = {}
    for combo in arms[3:]:
        target = sum(v.numel() for v in builder(hidden, combo, width).parameters())
        for arm in combo:
            match = matched_width(hidden, arm, target)
            if match['relative_error'] >= .01:
                raise ValueError('Capacity matching exceeds 1%')
            name = f'{arm}_matched_{len(combo)}'
            matches[f'{combo}:{arm}'] = dict(name=name, target=target, **match)
            if not any(c['name'] == name for c in configs):
                configs.append(dict(name=name, arm=arm, width=match['width'], control=f'matched_{len(combo)}'))
    return configs, matches


def fit(features, rows, mean, std, protocol, output, builder):
    device = protocol['device']; hidden = protocol['hidden']
    configs, seeds = protocol['configs'], protocol['head_seeds']
    features = {s:v.to(device) for s,v in features.items()}
    targets = {s:torch.tensor([r['label'] for r in rs], device=device) for s,rs in rows.items()}
    mean = torch.as_tensor(mean, device=device); std = torch.as_tensor(std, device=device)
    results = []
    for seed in seeds:
        for config in configs:
            started = time.perf_counter(); torch.manual_seed(seed)
            probe = builder(hidden, config['arm'], config['width']).to(device)
            optimizer = torch.optim.AdamW(probe.parameters(), lr=protocol['lr'], weight_decay=protocol['weight_decay'])
            folder = output/f'seed_{seed}'/config['name']; folder.mkdir(parents=True)
            best, best_epoch, history = float('inf'), 0, []
            for epoch in range(1, protocol['epochs']+1):
                probe.train()
                order = torch.randperm(len(rows['train']), generator=torch.Generator().manual_seed(seed*10000+epoch))
                for step, cpu_ids in enumerate(order.split(protocol['batch_size'])):
                    torch.manual_seed(seed*1000000+epoch*1000+step)
                    ids = cpu_ids.to(device)
                    loss = (probe(features['train'][ids])-(targets['train'][ids]-mean)/std).square().mean()
                    if not torch.isfinite(loss): raise FloatingPointError((seed, config, epoch, step))
                    optimizer.zero_grad(set_to_none=True); loss.backward()
                    torch.nn.utils.clip_grad_norm_(probe.parameters(), protocol['gradient_clip'], error_if_nonfinite=True)
                    optimizer.step()
                probe.eval()
                with torch.no_grad():
                    pred = probe(features['valid'])*std+mean
                    valid = float((pred-targets['valid']).square().mean().sqrt())
                if not torch.isfinite(torch.tensor(valid)): raise FloatingPointError('Nonfinite validation RMSE')
                history.append(dict(epoch=epoch, valid_rmse=valid))
                if valid < best:
                    best, best_epoch = valid, epoch
                    torch.save(dict(model={k:v.detach().cpu().clone() for k,v in probe.state_dict().items()},
                        epoch=epoch, mean=mean.cpu(), std=std.cpu(), config=config, seed=seed), folder/'best.pt')
                save_json(output/'status.json', dict(phase='training', seed=seed, config=config['name'],
                    epoch=epoch, best_epoch=best_epoch, completed=len(results), total=len(configs)*len(seeds)))
                if epoch-best_epoch >= protocol['patience']: break
            saved = torch.load(folder/'best.pt', map_location='cpu', weights_only=True)
            probe.load_state_dict(saved['model'], strict=True); probe.eval()
            with torch.no_grad():
                valid_pred = probe(features['valid'])*std+mean
                checked = float((valid_pred-targets['valid']).square().mean().sqrt())
                assert abs(checked-best) < 1e-6
                if protocol['smoke_only']:
                    reference = valid_pred.clone()
                    for v in probe.parameters(): v.add_(1)
                    probe.load_state_dict(saved['model'], strict=True)
                    torch.testing.assert_close(probe(features['valid'])*std+mean, reference, rtol=0, atol=0)
                else:
                    test_pred = probe(features['test'])*std+mean
                    test = float((test_pred-targets['test']).square().mean().sqrt())
            save_json(folder/'history.json', history)
            predictions = [('valid',valid_pred)] if protocol['smoke_only'] else [('valid',valid_pred),('test',test_pred)]
            for split, prediction in predictions:
                table(folder/f'{split}_predictions.csv', [dict(row=r['row'], target=r['label'], prediction=float(y))
                    for r,y in zip(rows[split], prediction.cpu())])
            result = dict(seed=seed, **config, parameters=sum(v.numel() for v in probe.parameters()),
                valid_rmse=best, best_epoch=best_epoch, epochs_run=epoch,
                reached_budget=epoch == protocol['epochs'], seconds=time.perf_counter()-started)
            if not protocol['smoke_only']: result['test_rmse'] = test
            results.append(result); save_json(output/'results_partial.json', results)
            print(dict(completed=len(results), total=len(configs)*len(seeds), seed=seed,
                       config=config['name'], epochs=epoch), flush=True)
    table(output/'runs.csv', results)
    if not protocol['smoke_only']:
        summary = []
        for config in configs:
            rr = [r for r in results if r['name'] == config['name']]
            values = [r['test_rmse'] for r in rr]
            summary.append(dict(**config, parameters=rr[0]['parameters'], n=len(values),
                test_rmse_mean=statistics.mean(values), test_rmse_sd=statistics.stdev(values) if len(values)>1 else 0))
        table(output/'summary.csv', summary)
        lookup = {(r['seed'],r['name']):r['test_rmse'] for r in results}
        paired = []
        arms = protocol['arms']
        for combo in arms[3:]:
            controls = list(combo)+[protocol['capacity_matches'][f'{combo}:{arm}']['name'] for arm in combo]
            if len(combo)==3: controls += list(arms[3:6])
            for control in controls:
                for seed in seeds:
                    paired.append(dict(combo=combo,control=control,seed=seed,
                                       delta_rmse=lookup[seed,combo]-lookup[seed,control]))
        table(output/'paired_deltas.csv', paired)
    completion = dict(passed=True, runs=len(results), smoke_only=protocol['smoke_only'],
        test_evaluations=0 if protocol['smoke_only'] else len(results),
        interpretation='one fixed task-adapted encoder, one split, head-seed variation only')
    save_json(output/'completion.json', completion)
    save_json(output/'status.json', dict(phase='complete',completed=len(results),total=len(results)))
    return completion
