"""Motif-scale controls. Upstream sources are never edited."""
import ast
import copy
import inspect
import torch
from rdkit import Chem


def atom_graph(row, loader):
    mol = Chem.MolFromSmiles(row['smiles'])
    atoms = [loader.atom_features(a) for a in mol.GetAtoms()]
    bonds, incoming, sources, reverse = [], [[] for _ in atoms], [], []
    for bond in mol.GetBonds():
        i, j = bond.GetBeginAtomIdx(), bond.GetEndAtomIdx()
        edge = loader.bond_features(bond)
        k = len(bonds)
        bonds.extend([atoms[i] + edge, atoms[j] + edge])
        incoming[j].append(k); incoming[i].append(k + 1)
        sources.extend([i, j]); reverse.extend([k + 1, k])
    # Match the author's no-motif branch, including its self-index entries.
    for i, feat in enumerate(atoms):
        k = len(bonds)
        incoming[i].append(k); sources.append(i); reverse.append(k)
        bonds.append(feat + [0] * 9)
    n = len(atoms)
    graph = dict(n_atoms=n+1, n_bonds=len(bonds),
                 f_atoms=atoms + [[sum(a[d] for a in atoms) for d in range(len(atoms[0]))]],
                 f_bonds=bonds, a2b=incoming+[[]], b2a=sources, b2revb=reverse,
                 num_part=torch.tensor([[n, 0, 1]]),
                 fp_x=torch.tensor([loader.get_fp_feature(mol)]), cliques=[])
    assert len(bonds) == 2*mol.GetNumBonds()+n
    assert all(0 <= x < n+1 for x in sources)
    assert all(reverse[reverse[k]] == k for k in range(len(reverse)))
    assert all(0 <= k < len(bonds) for ids in incoming for k in ids)
    return graph


HMG_REMOVE = ('frag_input_projection', 'frag_cross_atten', 'motif_encoder',
              'projector_atom', 'projector_frag')


def hmg_atom_model(full, output):
    """Derive the atom forward from the exact imported implementation, fail closed.

    Copy all upstream statements outside the contiguous motif and alignment
    blocks; replace only the view stack and return. Save generated code for review.
    """
    model = copy.deepcopy(full)
    tree = ast.parse(inspect.getsource(type(full)))
    fn = next(x for x in tree.body[0].body if isinstance(x, ast.FunctionDef) and x.name == 'forward')
    kept = []; removed = []; motif = alignment = False; stack_count = 0
    for node in fn.body:
        code = ast.unparse(node)
        if code.startswith('frag_features = F.relu('): motif = True
        if code.startswith('mol_feature_by_atom = '): motif = False
        if code.startswith('mol_feature_by_atom_projH = '): alignment = True
        if isinstance(node, ast.For) and 'descriptor_mlp' in code: alignment = False
        if motif or alignment:
            removed.append(code); continue
        if code.startswith('layer_neighbor_feature = '):
            node = ast.parse('layer_neighbor_feature = torch.stack([mol_feature_by_atom, mol_feature_by_des], dim=1)').body[0]
            stack_count += 1
        if isinstance(node, ast.Return):
            node = ast.parse('return output, output.sum() * 0').body[0]
        kept.append(node)
    assert stack_count == 1 and removed and any('ct_loss' in x for x in removed)
    fn.body = kept
    fn.args.args = [a for a in fn.args.args if a.arg not in ('frag_src_features', 'frag_src_valid_mask')]
    module = ast.fix_missing_locations(ast.Module(body=[fn], type_ignores=[]))
    source = ast.unparse(module)
    assert not any(x in source for x in ('frag_', 'motif_encoder', 'projector_', 'ct_loss'))
    output.write_text(source+'\n', encoding='utf-8')
    env = dict(type(full).forward.__globals__)
    exec(compile(module, str(output), 'exec'), env)
    # A distinct subclass prevents changing Full.forward.
    atom_cls = type('AtomOnlyHMG', (type(full),), {'forward': env['forward']})
    model.__class__ = atom_cls
    for name in HMG_REMOVE: delattr(model, name)
    return model


def copy_shared(full, atom):
    fs, ats = full.state_dict(), atom.state_dict()
    mismatch = [k for k in ats if k in fs and ats[k].shape != fs[k].shape]
    assert not mismatch, mismatch
    shared = sorted(set(fs) & set(ats))
    atom.load_state_dict({k: fs[k].clone() if k in fs else v for k,v in ats.items()}, strict=True)
    assert all(torch.equal(full.state_dict()[k], atom.state_dict()[k]) for k in shared)
    return dict(shared=shared, full_only=sorted(set(fs)-set(ats)),
                atom_only=sorted(set(ats)-set(fs)), shape_mismatch=mismatch,
                exact_equal=True)
