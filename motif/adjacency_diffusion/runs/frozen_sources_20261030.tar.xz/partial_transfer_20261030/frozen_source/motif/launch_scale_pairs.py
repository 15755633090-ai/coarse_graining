"""Freeze sources and run the fixed six paired training jobs sequentially."""
import argparse
import json
import shutil
import subprocess
import sys
import time
from pathlib import Path
from .data import save_json,sha


def worker(run):
    protocol=json.loads((run/'protocol.json').read_text(encoding='utf-8'))
    results=[]
    try:
        for seed in protocol['seeds']:
            for paper,prefix in [('HimNet','him'),('HMG-MRL','hmg')]:
                name=f'{prefix}_seed{seed}';output=run/name
                cmd=[sys.executable,'-X','utf8','-u','-m','motif.train_scale_pair',
                     '--paper',paper,'--paper-root',str(run/'upstream'/prefix),
                     '--data',protocol['data'],'--preflight-dir',protocol['preflight'][prefix],
                     '--seed',str(seed),'--epochs','100','--patience','20','--batch-size','16','--lr','0.0001',
                     '--output',str(output)]
                if prefix=='hmg':cmd+=['--feature-cache',protocol['feature_cache']]
                with (run/f'{name}.stdout.log').open('w',encoding='utf-8') as out,(run/f'{name}.stderr.log').open('w',encoding='utf-8') as err:
                    proc=subprocess.Popen(cmd,cwd=run/'source',stdout=out,stderr=err,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
                    save_json(run/f'{name}.process.json',{'pid':proc.pid,'command':cmd})
                    save_json(run/'status.json',{'phase':'running','stage':name,'pid':proc.pid,'completed_pairs':len(results),'updated':time.time()})
                    code=proc.wait()
                save_json(run/f'{name}.exit.json',{'exit_code':code})
                if code:raise RuntimeError(f'{name} failed with exit {code}; queue stopped')
                r=json.loads((output/'results.json').read_text(encoding='utf-8'))
                assert not r['smoke'] and r['shared_initialization_exact'] and r['source_unchanged']
                results.append(r);save_json(run/'completed_results.json',results)
        import numpy as np
        from scipy.stats import t
        summary={}
        for paper in ('HimNet','HMG-MRL'):
            pairs=[r for r in results if r['paper']==paper]
            delta=np.array([r['delta_rmse'] for r in pairs]);n=len(delta)
            mean=float(delta.mean());sd=float(delta.std(ddof=1));half=float(t.ppf(.975,n-1)*sd/np.sqrt(n))
            summary[paper]={'seeds':[r['seed'] for r in pairs],'paired_delta_rmse':delta.tolist(),
                            'mean_delta_rmse':mean,'sample_sd':sd,'paired_t_95_ci':[mean-half,mean+half],
                            'scope':'fixed split, training randomness only; n=3 unstable; no cross-scaffold claim'}
        save_json(run/'comparison.json',summary)
        save_json(run/'status.json',{'phase':'complete','completed_pairs':len(results),'updated':time.time()})
    except Exception as exc:
        save_json(run/'status.json',{'phase':'failed','error':str(exc),'completed_pairs':len(results),'updated':time.time()});raise


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--worker',action='store_true');a=p.parse_args();run=a.output.resolve()
    if a.worker:worker(run);return
    root=Path(__file__).resolve().parents[1]
    # Gate launch on complete-input preflight plus multi-epoch acceptance.
    for prefix in ('him','hmg'):
        pf=json.loads((root/f'motif/runs/scale_preflight_{prefix}_20261018/preflight.json').read_text(encoding='utf-8'))
        smoke=json.loads((root/f'motif/runs/scale_multiepoch_{prefix}_20261018/results.json').read_text(encoding='utf-8'))
        assert pf['passed'] and pf['index_validated_rows']==4200
        assert smoke['smoke'] and not smoke['test_evaluated'] and smoke['source_unchanged']
        dynamic=json.loads((root/f'motif/runs/scale_acceptance_{prefix}_v2_20261018/acceptance.json').read_text(encoding='utf-8'))
        assert dynamic['passed'] and all(v['reload_exact'] for v in smoke['arms'].values())
    run.mkdir(parents=True,exist_ok=False)
    source=run/'source'/'motif';source.mkdir(parents=True)
    for f in (root/'motif').glob('*.py'):shutil.copy2(f,source/f.name)
    paper_roots={'him':root/'coarse_graining1/HimNet_reproduction_20261013/windows','hmg':root/'research_code_audit/HMG-MRL'}
    for prefix,paper_root in paper_roots.items():
        for f in paper_root.rglob('*.py'):
            dst=run/'upstream'/prefix/f.relative_to(paper_root);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,dst)
    protocol={'scope':'paper mechanisms under unified supervised protocol; no diffusion; no separate No-motif',
              'seeds':[0,1,2],'arms':['full','atom'],'data':str(root/'motif/data/lipo.pt'),
              'feature_cache':str(root/'motif/runs/hmg_features_finite_20261016/features.pickle'),
              'preflight':{prefix:str(root/f'motif/runs/scale_preflight_{prefix}_20261018') for prefix in ('him','hmg')},
              'epochs':100,'patience':20,'batch_size':16,'lr':1e-4,'weight_decay':1e-5,'gradient_clip':5,
              'selection':'lowest validation RMSE, strict improvement; test once after reload per arm',
              'paired_initialization':'explicit shared state copy, exact tensor equality',
              'paired_order':'seed+epoch local generator; identical batch row IDs; singleton merged',
              'test_previously_seen':True,'hmg_capacity_matched':False,
              'ci':'paired Student-t 95%, n=3; fixed split training randomness only'}
    save_json(run/'protocol.json',protocol)
    save_json(run/'source_manifest.json',{str(f.relative_to(run)):sha(f) for folder in ('source','upstream') for f in (run/folder).rglob('*.py')})
    save_json(run/'status.json',{'phase':'prepared','updated':time.time()})
    print({'prepared':str(run),'worker_cwd':str(run/'source')},flush=True)


if __name__=='__main__':main()
