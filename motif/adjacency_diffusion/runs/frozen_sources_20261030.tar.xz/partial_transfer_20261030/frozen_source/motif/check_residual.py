"""Check original information preservation and both gradient paths."""
import torch
from torch import nn
from .adapters import _BoundProjection

def main():
    torch.manual_seed(42)
    base=nn.Linear(5,7);projection=_BoundProjection(base,3,'residual',.1)
    x=torch.randn(2,4,5,requires_grad=True);vectors=torch.randn(2,3,requires_grad=True)
    before=base(x);token=projection.override.set((vectors,[[0,1],[1,2]]))
    try:out=projection(x)
    finally:projection.override.reset(token)
    mask=torch.ones(2,4,dtype=torch.bool);mask[0,1]=mask[1,2]=False
    torch.testing.assert_close(out[mask],before[mask])
    torch.testing.assert_close(out[0,1],before[0,1]+.1*projection.motif_projection(vectors)[0])
    loss=out[0,1].square().sum()+out[1,2].square().sum();loss.backward()
    for grad in (base.weight.grad,vectors.grad,projection.motif_projection.weight.grad,projection.motif_gate.grad):
        assert grad is not None and torch.isfinite(grad).all() and grad.abs().sum()>0
    replica=_BoundProjection(nn.Linear(5,7),3,'residual',.1)
    replica.load_state_dict(projection.state_dict(),strict=True)
    assert projection.override.get() is None
    print('PASS original path, unbound tokens, 0.1 gate, both gradient paths, strict reload')

if __name__=='__main__':main()
