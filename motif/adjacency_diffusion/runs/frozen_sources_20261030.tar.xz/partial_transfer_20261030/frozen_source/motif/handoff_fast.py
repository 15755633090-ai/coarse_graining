"""Finish the existing child unchanged, then resume from a new source snapshot."""
import json
import sys
import time
from pathlib import Path
import psutil

def save(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')

def main():
    run=Path(sys.argv[1]);root=Path(sys.argv[2])
    handoff=json.loads((run/'fast_handoff.json').read_text(encoding='utf-8'))
    try:
        try:
            process=psutil.Process(handoff['training_pid'])
            if abs(process.create_time()-handoff['training_created'])<.01:
                while True:
                    try:process.wait(timeout=30);break
                    except psutil.TimeoutExpired:pass
        except psutil.NoSuchProcess:pass
        stage=handoff['stage'];output=run/stage
        result=json.loads((output/'results.json').read_text(encoding='utf-8'))
        if result['smoke'] or result['paper']!='HimNet':raise ValueError('Invalid handoff result')
        completed=json.loads((run/'completed_results.json').read_text(encoding='utf-8'))
        key=(1,'HimNet','residual')
        if not any((r['seed'],r['paper'],r['fusion'])==key for r in completed):
            completed.append({'seed':1,'paper':'HimNet','fusion':'residual','reused':False,'path':str(output),'result':result})
            save(run/'completed_results.json',completed)
        handoff['phase']='fast_queue_started';handoff['transitioned_at']=time.time()
        save(run/'fast_handoff.json',handoff)
        from .launch_residual import worker
        worker(run,root,resume=True,fast_fullgraph=True)
    except Exception as exc:
        save(run/'status.json',{'phase':'failed','error':str(exc),'updated':time.time()});raise

if __name__=='__main__':main()
