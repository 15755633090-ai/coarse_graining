"""Read HMG-MRL's existing atom, motif, descriptor views before fusion."""
import copy
import inspect

import torch
from torch import nn

from .him_scale_readout import ScaleProbe

ARMS = ('A', 'S', 'D', 'AS', 'AD', 'SD', 'ASD')


class HMGScaleReadout(nn.Module):
    def __init__(self, model, frozen=True):
        super().__init__()
        source = inspect.getsource(type(model).forward)
        expected = 'torch.stack([frag_cls, mol_feature_by_atom, mol_feature_by_des], dim=1)'
        if source.count(expected) != 1:
            raise ValueError('Unrecognized upstream HMG view order')
        self.model = copy.deepcopy(model)
        self.frozen = frozen
        if frozen:
            self.model.requires_grad_(False)
            self.model.eval()

    def train(self, mode=True):
        super().train(mode)
        if self.frozen:
            self.model.eval()
        return self

    def forward(self, **inputs):
        captured = []
        def capture(module, args):
            captured.append(args[1])
        handle = self.model.layer_atten.register_forward_pre_hook(capture)
        try:
            original = self.model(**inputs)
        finally:
            handle.remove()
        if len(captured) != 1 or captured[0].shape[1] != 3:
            raise ValueError('Expected one three-view fusion')
        views = captured[0]  # Author's order: S, A, D.
        z = views[:, (1, 0, 2), :]
        return dict(z=z, full=original[6], prediction=original[1], source_views=views)


class BranchProbe(ScaleProbe):
    """Use the identical head architecture, with the third slot named D."""
    def __init__(self, hidden, arm, width=128, dropout=.1):
        if arm not in ARMS:
            raise ValueError(arm)
        super().__init__(hidden, arm.replace('D', 'G'), width, dropout)
        self.arm = arm
