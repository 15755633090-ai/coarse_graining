"""Shared model construction and complete-input validation for scale controls."""
import copy
import torch
from rdkit import Chem
from .data import sha, save_json
from .paper_data import (load_paper, prepare_him_graphs, HierarchicalBatch,
                         load_hmg_features, hmg_inputs, source_inventory)
from .scale_ablation import atom_graph, hmg_atom_model, copy_shared


def him_alignment_parts(model,temperature=.1):
    d=model.contrastive_data; labels=torch.arange(d['graph_proj'].shape[0],device=d['graph_proj'].device)
    def symmetric(a,b):
        sim=a@b.t()/temperature
        return (torch.nn.functional.cross_entropy(sim,labels)+torch.nn.functional.cross_entropy(sim.t(),labels))/2
    graph=symmetric(d['graph_proj'],d['fp_proj'])
    views=list(d['fp_view_projs'].values())
    pairs=[symmetric(views[i],views[j]) for i in range(len(views)) for j in range(i+1,len(views))]
    view=sum(pairs)/len(pairs) if pairs else graph*0
    return graph,.5*view


def validate_him(g):
    n,b=g['n_atoms'],g['n_bonds']
    assert n==len(g['f_atoms'])==len(g['a2b'])
    assert b==len(g['f_bonds'])==len(g['b2a'])==len(g['b2revb'])
    assert sum(int(x) for x in g['num_part'][0])==n
    assert all(0<=i<n for i in g['b2a'])
    assert all(0<=i<b for i in g['b2revb'])
    assert all(g['b2revb'][g['b2revb'][i]]==i for i in range(b))
    assert all(0<=i<b for incoming in g['a2b'] for i in incoming)
    for name in ('f_atoms','f_bonds','fp_x'):
        assert torch.isfinite(torch.as_tensor(g[name])).all(),name


def validate_hmg(x, rows):
    na,nb=x['x_atoms'].shape[1],x['x_bonds'].shape[1]
    for key,limit in [('atom_neighbors_atom_index',na),('atom_neighbors_bond_index',nb),
                      ('bond_neighbors_atom_index',na),('bond_neighbors_bond_index',nb)]:
        t=x[key]; assert t.dtype==torch.long and t.min()>=0 and t.max()<limit,key
    for name in ('atom_mask','bond_mask','frag_src_valid_mask'):
        assert ((x[name]==0)|(x[name]==1)).all(),name
    for i,r in enumerate(rows):
        mol=Chem.MolFromSmiles(r['smiles'])
        assert int(x['atom_mask'][i].sum())==mol.GetNumAtoms(),r['row']
        assert int(x['bond_mask'][i].sum())==mol.GetNumBonds(),r['row']
    assert (x['atom_mask'][:,-1]==0).all() and (x['bond_mask'][:,-1]==0).all()


class ScaleRuntime:
    def __init__(self,paper,root,rows,output,seed,device='cuda:0',features=None,graph_cache=None,him_repair=False):
        self.paper,self.device=paper,device
        cls,loader,cfg=load_paper(root,paper,device)
        self.source=source_inventory(root)
        torch.manual_seed(seed+2000)
        if paper=='HimNet':
            if graph_cache:
                cached=torch.load(graph_cache,map_location='cpu',weights_only=True)
                self.graphs=cached['graphs']
            else: self.graphs=prepare_him_graphs(rows,loader)
            if him_repair:
                from .him_repair_20261019.graphs import SCHEMA
                assert graph_cache and cached['repair_schema']==SCHEMA
                self.atomgraphs=cached['atomgraphs']
            else:self.atomgraphs={r['row']:atom_graph(r,loader) for r in rows}
            for r in rows:
                f,a=self.graphs[r['row']],self.atomgraphs[r['row']]; validate_him(f); validate_him(a)
                n=int(a['num_part'][0][0]); nb=Chem.MolFromSmiles(r['smiles']).GetNumBonds()*2
                assert f['f_atoms'][:n]==a['f_atoms'][:n] and f['f_atoms'][-1]==a['f_atoms'][-1]
                assert f['f_bonds'][:nb]==a['f_bonds'][:nb]
                assert torch.equal(f['fp_x'],a['fp_x'])
            g=self.graphs[rows[0]['row']]
            self.full=cls('memory',len(g['f_atoms'][0]),len(g['f_bonds'][0]),g['fp_x'].shape[-1],device=device,out_dim=1).to(device)
            if him_repair:
                from .him_repair_20261019.HGNNEncoder import HGNNEncoder
                old=self.full.encoder.mpnn_encoder
                corrected=HGNNEncoder(old.atom_fdim,old.bond_fdim,old.hidden_size,old.depth,device).to(device)
                corrected.load_state_dict(old.state_dict(),strict=True)
                self.full.encoder.mpnn_encoder=corrected
            self.atom=copy.deepcopy(self.full); self.weight=.2
        else:
            self.features,self.assemble=load_hmg_features(features,root)
            sample,_,_=hmg_inputs(rows[:2],self.features,self.assemble,device)
            cfg.atom_dim_in=sample['x_atoms'].shape[-1];cfg.bond_dim_in=sample['x_bonds'].shape[-1]
            self.full=cls(cfg.atom_dim_in,cfg.bond_dim_in,1).to(device)
            self.atom=hmg_atom_model(self.full,output/'atom_forward.py');self.weight=cfg.ct_loss_coff
        self.mapping=copy_shared(self.full,self.atom)
        save_json(output/'initialization.json',self.mapping)

    def forward(self,model,rows,arm,training):
        if self.paper=='HimNet':
            graphs=self.graphs if arm=='full' else self.atomgraphs
            batch=HierarchicalBatch([graphs[r['row']] for r in rows])
            ligand=model.encoder(batch)
            if training:
                fp,proj,views=model.fp_encoder(batch.fp_x.to(self.device).float(),training=True)
                model.contrastive_data={'graph_proj':torch.nn.functional.normalize(model.graph_proj_head(ligand),dim=1),
                                        'fp_proj':proj,'fp_view_projs':views}
                aux=model.compute_contrastive_loss()
                if getattr(self,'loss_ablation',False):
                    _,aux=him_alignment_parts(model)
            else:
                fp=model.fp_encoder(batch.fp_x.to(self.device).float());aux=ligand.sum()*0
            return model.mlp(model.feature_fusion(torch.stack([ligand,fp]))).flatten(),aux
        kw,_,_=hmg_inputs(rows,self.features,self.assemble,self.device)
        if arm=='atom':
            del kw['frag_src_features'];del kw['frag_src_valid_mask']
            pred,aux=model(**kw)
        else:
            out=model(**kw);pred,aux=out[1],out[2]
            if getattr(self,'loss_ablation',False):aux=pred.sum()*0
        return pred.flatten(),aux
