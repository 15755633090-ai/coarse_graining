"""Compare outputs, all active gradients, and synchronized real-data timings."""
import argparse
import time
from pathlib import Path
import torch
from .fullgraph import FullGraphEncoder,records
from .fullgraph_fast import FastFullGraphEncoder
from .data import load_dataset,save_json

def main():
    p=argparse.ArgumentParser();p.add_argument('--method',choices=['HimNet','HMG-MRL'],required=True)
    p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    torch.set_num_threads(4);torch.manual_seed(71)
    device='cuda' if torch.cuda.is_available() else 'cpu'
    prefix='him' if args.method=='HimNet' else 'hmg'
    ck=torch.load(f'motif/runs/fullgraph_formal_seed0_20261016/{prefix}_pretrain/best.pt',map_location='cpu',weights_only=True)
    data=load_dataset('motif/data/lipo.pt')
    items=records(data,[r for r in data['molecules'] if r['split']=='train'][:16],args.method,ck['vocab'])
    old=FullGraphEncoder(ck['model_config'],ck['vocab']).to(device)
    fast=FastFullGraphEncoder(ck['model_config'],ck['vocab']).to(device)
    for model in (old,fast):model.load_state_dict(ck['model'],strict=True);model.eval()
    # Disable TF32: changing GEMM batch size must not change precision policy.
    torch.backends.cuda.matmul.allow_tf32=False
    torch.backends.cudnn.allow_tf32=False
    a=old.encode_records(items,4);b=fast.encode_records(items,4)
    torch.testing.assert_close(a,b,rtol=2e-4,atol=2e-5)
    weight=torch.randn_like(a)
    (a*weight).sum().backward();(b*weight).sum().backward()
    grad_errors={}
    for (name,x),(other,y) in zip(old.named_parameters(),fast.named_parameters()):
        assert name==other
        if x.grad is None or y.grad is None:assert x.grad is None and y.grad is None;continue
        torch.testing.assert_close(x.grad,y.grad,rtol=3e-3,atol=3e-4,msg=lambda msg:name+': '+msg)
        grad_errors[name]=float((x.grad-y.grad).abs().max())
    # Exercise uncovered atoms, overlaps, empty motifs, mixed sizes, singleton
    # chunk fallback and original motif order without changing graph features.
    custom=[{**items[0],'members':[[0,1],[1,2]],'types':[1,1]},
            {**items[1],'members':[],'types':[]}]
    torch.testing.assert_close(old.encode_records(custom,2),fast.encode_records(custom,2),rtol=2e-4,atol=2e-5)
    timings={}
    def sync():
        if device=='cuda':torch.cuda.synchronize()
    for label,model in [('old',old),('fast',fast)]:
        def step():
            model.zero_grad(set_to_none=True)
            model.encode_records(items,4).square().mean().backward()
        for _ in range(2):step()
        sync();start=time.perf_counter()
        for _ in range(6):step()
        sync();timings[label]=(time.perf_counter()-start)/6
    # Time the fixed structural CPU assembly/condition and encoding+pooling
    # separately. No change to training batch size, dropout or original paper.
    report={'method':args.method,'device':device,'molecules':len(items),'motifs':len(a),
        'outputs_passed':True,'all_active_gradients_passed':True,'overlap_empty_uncovered_passed':True,
        'max_output_abs_error':float((a-b).detach().abs().max()),'max_gradient_abs_error':max(grad_errors.values()),
        'seconds_forward_backward':timings,'encoder_speedup':timings['old']/timings['fast'],
        'scope':'fullgraph branch only; competing existing training may affect timings',
        'training_equivalence':'dropout was disabled for numeric check; identical batch boundaries and parameter schema'}
    save_json(args.output,report);print(report,flush=True)

if __name__=='__main__':main()
