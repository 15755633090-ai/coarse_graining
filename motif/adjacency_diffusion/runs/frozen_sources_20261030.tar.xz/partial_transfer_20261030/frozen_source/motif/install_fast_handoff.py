"""One-time process handoff; never terminates the active training subtree."""
import json
import subprocess
import sys
import time
from pathlib import Path
import psutil

def save(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')

def main():
    root=Path(__file__).resolve().parents[1];run=root/'motif/runs/fullgraph_residual_3seeds_20261016'
    status=json.loads((run/'status.json').read_text(encoding='utf-8'))
    if status['stage']!='him_residual_seed1':raise RuntimeError('Stage advanced; inspect before installing handoff')
    training=psutil.Process(status['pid'])
    if 'motif.train_paper' not in ' '.join(training.cmdline()):raise RuntimeError('Training process identity mismatch')
    worker_id=json.loads((run/'worker.json').read_text(encoding='utf-8-sig'))['pid']
    ancestors=[];parent=training.parent()
    while parent is not None:
        ancestors.append(parent)
        if parent.pid==worker_id:break
        parent=parent.parent()
    if not ancestors or ancestors[-1].pid!=worker_id:raise RuntimeError('Worker ancestry mismatch')
    if not any('motif.launch_residual' in ' '.join(p.cmdline()) for p in ancestors):raise RuntimeError('Unrecognized worker')
    suspended=[]
    try:
        for process in reversed(ancestors):process.suspend();suspended.append(process)
        # No new stage can be spawned after all orchestrator ancestors suspend.
        if json.loads((run/'status.json').read_text(encoding='utf-8'))['pid']!=training.pid:
            raise RuntimeError('Stage changed during handoff')
        record={'phase':'waiting_current_training','stage':status['stage'],'training_pid':training.pid,
            'training_created':training.create_time(),'old_worker_pids':[p.pid for p in ancestors],
            'old_source':str(run/'source'),'new_source':str(run/'source_fast'),
            'created':time.time(),'remaining_pretrained_runs_fast':True,
            'unchanged':'batch boundaries, parameters, optimizer, seeds, budgets; floating point roundoff may differ'}
        save(run/'fast_handoff.json',record)
        cmd=[sys.executable,'-X','utf8','-u','-m','motif.handoff_fast',str(run),str(root)]
        with (run/'worker_fast.stdout.log').open('w',encoding='utf-8') as out,(run/'worker_fast.stderr.log').open('w',encoding='utf-8') as err:
            new=subprocess.Popen(cmd,cwd=run/'source_fast',stdout=out,stderr=err,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        save(run/'worker_before_fast.json',{'pids':[p.pid for p in ancestors]})
        save(run/'worker.json',{'pid':new.pid,'mode':'wait current child then fast resume','created':time.time()})
    except Exception:
        for process in suspended:
            try:process.resume()
            except psutil.NoSuchProcess:pass
        raise
    for process in ancestors:
        try:process.terminate()
        except psutil.NoSuchProcess:pass
    print(json.dumps({'new_worker_pid':new.pid,'preserved_training_pid':training.pid,'phase':'waiting_current_training'}))

if __name__=='__main__':main()
